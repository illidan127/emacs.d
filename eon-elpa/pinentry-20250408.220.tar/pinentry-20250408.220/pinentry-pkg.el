;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinentry" "20250408.220"
  "GnuPG Pinentry server implementation."
  ()
  :url "https://github.com/ueno/pinentry-el"
  :commit "0079964a1dde954ccb2ce8a28613d8020c549a36"
  :revdesc "0079964a1dde"
  :keywords '("gnupg")
  :authors '(("Daiki Ueno" . "ueno@gnu.org"))
  :maintainers '(("Daiki Ueno" . "ueno@gnu.org")))
