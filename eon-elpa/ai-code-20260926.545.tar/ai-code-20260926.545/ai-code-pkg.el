;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260926.545"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "024722baaf7249b666cf255ed11b2cf4f4235a04"
  :revdesc "024722baaf72"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
