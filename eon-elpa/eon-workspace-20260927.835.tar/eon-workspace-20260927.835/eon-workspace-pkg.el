;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eon-workspace" "20260927.835"
  "Frame-based workspaces with project root."
  '((emacs "27.1"))
  :url "https://github.com/illidan127/eon-workspace"
  :commit "a3bd61daa08be513621e278dff9e140c013a5bdd"
  :revdesc "a3bd61daa08b"
  :keywords '("convenience" "workspace" "frames" "project"))
