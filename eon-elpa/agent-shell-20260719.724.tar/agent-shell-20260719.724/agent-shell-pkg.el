;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260719.724"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4a4b98b008ce9dba2edf22dc3a265abd1679ab0d"
  :revdesc "4a4b98b008ce")
