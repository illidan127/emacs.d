;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "valign" "20210502.111"
  "Visually align tables."
  '((emacs "26.0"))
  :url "https://github.com/casouri/valign"
  :commit "be82f6048118cbc81e6e029be1965f933612d871"
  :revdesc "be82f6048118"
  :keywords '("convenience" "text" "table")
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
