;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260522.238"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "321f4382055be37062262f915f73d28352570df7"
  :revdesc "321f4382055b")
