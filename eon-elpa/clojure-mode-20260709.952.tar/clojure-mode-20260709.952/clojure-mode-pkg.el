;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260709.952"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "38c72d3284367459a8b116deb660c3163f6653ea"
  :revdesc "38c72d328436"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
