;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sokoban" "20130328.949"
  "Implementation of Sokoban for Emacs."
  ()
  :commit "962e97bb275b7d425ded54330c3057879968f726"
  :revdesc "962e97bb275b"
  :keywords '("games")
  :authors '(("Glynn Clements" . "glynn.clements@virgin.net"))
  :maintainers '(("Glynn Clements" . "glynn.clements@virgin.net")))
