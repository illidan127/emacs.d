;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20250716.1405"
  "Manage and navigate projects in Emacs easily."
  '((emacs "26.1"))
  :url "https://github.com/bbatsov/projectile"
  :commit "9325c45e0fd96d5421e75ad901a91ee5353e10ad"
  :revdesc "9325c45e0fd9"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
