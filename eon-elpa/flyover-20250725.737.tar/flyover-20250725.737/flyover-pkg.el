;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20250725.737"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "46ec62f3a203e1b5d351a4ed42a38d93eca14b7c"
  :revdesc "46ec62f3a203"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
