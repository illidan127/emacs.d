;;; whisper.el --- Speech-to-Text interface using OpenAI's whisper model -*- lexical-binding: t; -*-

;; Copyright (C) 2022 Imran Khan.

;; Author: Imran Khan <imran@khan.ovh>
;; URL: https://github.com/natrys/whisper.el
;; Package-Version: 20260309.1304
;; Package-Revision: 1858f49e07e5
;; Package-Requires: ((emacs "27.1"))

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or (at
;; your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Speech-to-Text interface for Emacs using OpenAI's whisper model
;; Uses the awesome C/C++ port that runs on CPU.
;; See: https://github.com/ggerganov/whisper.cpp
;;
;;; Code:

(require 'cl-lib)
(require 'url-parse)
(require 'whisper-languages)

;;; User facing options

(defgroup whisper ()
  "Speech-to-text interface using OpenAI's whisper model."
  :group 'external)

(defcustom whisper-enable-speed-up nil
  "Whether to sacrifices some accuracy to speed up transcribing.

Basically whether to use \"-su\" flag in whisper.cpp.  You should experiment
enabling it to see if it works well enough for you.

It's currently disabled by upstream because of bugs, so does nothing."
  :type 'boolean
  :group 'whisper)

(defcustom whisper-use-threads nil
  "How many threads to use for transcribing.

Default is whisper.cpp default (which is number of cores but maxed at 4)."
  :type 'integer
  :group 'whisper)

(defcustom whisper-install-directory (locate-user-emacs-file ".cache/")
  "Location of where whisper.cpp is installed."
  :type 'directory
  :group 'whisper
  :set (lambda (sym val)
         (set-default sym val)
         (setq whisper--install-path
               (concat
                (expand-file-name (file-name-as-directory val))
                "whisper.cpp/"))))

(defcustom whisper-recording-timeout 300
  "Number of seconds after which recording will be automatically stopped."
  :type '(choice integer (const nil))
  :group 'whisper)

(defcustom whisper-model "base"
  "Which whisper model to use (default is base).

Choose between: tiny, base, small, medium, large.

The first four comes with .en variant that only works with English, but
might speed up transcribing."
  :type 'string
  :group 'whisper)

(defcustom whisper-language "en"
  "Set spoken language for audio.

When dealing with unknown language, set this to `auto'.

Be sure to use generic model (without .en suffix) when language is not English."
  :type 'string
  :group 'whisper)

(defcustom whisper-translate nil
  "Whether to translate to English first, before transcribing."
  :type 'boolean
  :group 'whisper)

(defcustom whisper-quantize nil
  "Whether to use quantized version of the model in whisper.cpp.

Quantization is a technique to reduce the computational and memory costs of
running inference by representing the weights and activations with low-precision
data types.  This sacrifices precision for resource efficiency.  The idea is
that quantized version of bigger model may afford you to use it (if you are RAM
constrained e.g.) with some penalty, while still being better than the smaller
model you would be using otherwise.

Valid values are (from lowest to highest quality):
- q4_0
- q4_1
- q4_k
- q5_0
- q5_1
- q5_k
- q6_k
- q8_0"
  :type '(choice string (const nil))
  :group 'whisper)

(defcustom whisper-install-whispercpp t
  "Specify whether to install whisper.cpp automatically.

By default whisper.el compiles whisper.cpp automatically.   But if you are on a
platform where our automatic whisper.cpp install doesn't work but you are able
to do so manually, you can set this to `manual' to skip our try (and failure)
to install it automatically.  Note that in case a functional install is found
at `whisper-install-directory', we can still do model download, quantization
automatically.

But if you are planning to use something other than whisper.cpp entirely, as
such don't want to install it nor run checks for it, you may opt out of
whisper.cpp as a whole by setting this to nil.  In that case it's your
responsibility to override `whisper-command' with appropriate function."
  :type '(choice boolean (const manual))
  :group 'whisper)

(defcustom whisper-server-mode nil
  "Server mode to use for transcription.
Possible values:
- nil: Use local whisper.cpp directly
- local: Run whisper.cpp as local HTTP server
- remote: Use a remote whisper.cpp server
- openai: Use OpenAI's Whisper API (requires API key)"
  :type '(choice (const :tag "Direct" nil)
                 (const :tag "Local Server" local)
                 (const :tag "Remote Server" remote)
                 (const :tag "OpenAI API" openai))
  :set (lambda (sym val)
         (set-default sym val)
         (when (bound-and-true-p whisper--server-process)
           (delete-process whisper--server-process)
           (setq whisper--server-process nil)))
  :group 'whisper)

(defcustom whisper-server-baseurl nil
  "Base URL for the whisper server.
This should be the full URL including protocol, host, and port.
For example: \"http://localhost:8642\" or \"https://whisper.example.com\"

If this is nil, falls back to constructing URL from `whisper-server-host'
and `whisper-server-port' (for backward compatibility)."
  :type '(choice (const :tag "Use host/port instead (for backward compatibility)" nil)
                 string)
  :group 'whisper)

(define-obsolete-variable-alias 'whisper-server-host 'whisper-server-baseurl "0.4.5")
(defcustom whisper-server-host "127.0.0.1"
  "Host address for the whisper server.
This is now only used when `whisper-server-baseurl' is nil."
  :type 'string
  :group 'whisper)

(define-obsolete-variable-alias 'whisper-server-port 'whisper-server-baseurl "0.4.5")
(defcustom whisper-server-port 8642
  "Port number for the whisper server.
This is now only used when `whisper-server-baseurl' is nil."
  :type 'integer
  :group 'whisper)

(defcustom whisper-openai-api-baseurl "https://api.openai.com/"
  "URL for OpenAI compatible transcription API endpoint."
  :type 'string
  :group 'whisper)

(defcustom whisper-openai-api-key nil
  "API key for OpenAI compatible transcription API.
Required when using openai server mode."
  :type '(choice (const nil) string)
  :group 'whisper)

(defcustom whisper-openai-model "gpt-4o-transcribe"
  "Model to use in OpenAI compatible API."
  :type 'string
  :group 'whisper)

(defcustom whisper-insert-text-at-point t
  "Whether to put whisper output under point in current buffer.

When nil, instead of inserting text under current point, a temporary buffer
containing whisper output text is created.  The buffer name is distinguished
with current timestamp and it's the user's responsibility to kill the buffer if
they want to.  Whether this buffer is displayed is controlled by
`whisper-display-transcription-buffer'."
  :type 'boolean
  :group 'whisper)

(defcustom whisper-display-transcription-buffer t
  "Whether to display the temporary buffer with transcription.

This variable only has an effect when `whisper-insert-text-at-point' is nil.
When non-nil, the buffer with transcription is displayed.
When nil, the buffer is created but not displayed.  This is useful for
non-interactive scripting where user only intends to run the functions in
`whisper-after-transcription-hook' and do their own thing with result."
  :type 'boolean
  :group 'whisper)

(defcustom whisper-transcription-buffer-name-function #'whisper--timestamped-transcription-buffer-name
  "Function to generate the name of the transcription buffer.

By default we create a timestamp based new buffer, but if you prefer to name
it something simple and deterministic to avoid proliferation of such buffers
then set it to `whisper--simple-transcription-buffer-name' instead."
  :group 'whisper)

(define-obsolete-variable-alias 'whisper-return-cursor-to-start 'whisper-return-cursor "0.4.6")
(defcustom whisper-return-cursor-to-start t
  "Whether to re-position the cursor after transcription.

This variable is obsolete; use `whisper-return-cursor' instead.

When non-nil, the cursor is returned to the original invocation point.
Otherwise, the cursor remains at the end of the inserted transcription."
  :type 'boolean
  :set (lambda (sym val)
         (set-default sym val)
         (setq whisper-return-cursor (if val 'start 'end)))
  :group 'whisper)

(defcustom whisper-return-cursor whisper-return-cursor-to-start
  "Where to place cursor after transcription text is inserted.

The text is always inserted at the original invocation point, but this
controls where the cursor ends up afterwards.

Possible values:
- nil: cursor doesn't move
- `start': cursor moves to start of inserted text
- `end': cursor moves to end of inserted text"
  :type '(choice (const :tag "Stay where cursor is" nil)
                 (const :tag "At start of inserted text" start)
                 (const :tag "At end of inserted text" end))
  :group 'whisper)

(defcustom whisper-show-progress-in-mode-line t
  "Whether to show transcription progress in mode line."
  :type 'boolean
  :group 'whisper)

(define-obsolete-variable-alias 'whisper-pre-process-hook 'whisper-before-transcription-hook "0.3.0")
(defcustom whisper-before-transcription-hook '(whisper--check-buffer-read-only-p)
  "Hook run before whisper.el does anything."
  :type 'hook
  :group 'whisper)

(define-obsolete-variable-alias 'whisper-post-process-hook 'whisper-after-transcription-hook "0.3.0")
(defcustom whisper-after-transcription-hook nil
  "Hook run after whisper command finishes producing output.

If you want to transform the command output text in some way before they are
inserted into the original buffer, add your function here.  Each function in
the hook will be run in a buffer containing the whisper command output text
as its current buffer, and with point set to beginning of that buffer."
  :type 'hook
  :group 'whisper)

(defcustom whisper-after-insert-hook nil
  "Hook run after whisper command has inserted the transcription.

This hook will be run in the original buffer the text was just inserted."
  :type 'hook
  :group 'whisper)

;;; Internal variables

(defvar whisper--stdout-buffer-name "*whisper-stdout*")
(defvar whisper--stderr-buffer-name "*whisper-stderr*")
(defvar whisper--compilation-buffer-name "*whisper-compilation*")

(defvar whisper--point-buffer nil)
(defvar whisper--compilation-buffer nil)

(defvar whisper--recording-process nil)
(defvar whisper--transcribing-process nil)
(defvar whisper--server-process nil)

;; Kill server process when Emacs exits
(add-hook 'kill-emacs-hook
          (lambda ()
            (when (process-live-p whisper--server-process)
              (delete-process whisper--server-process))))

(defvar whisper--marker (make-marker))

(defvar whisper--install-path
  (when whisper-install-directory
    (concat
     (expand-file-name (file-name-as-directory whisper-install-directory))
     "whisper.cpp/")))

(defvar whisper--temp-file
  (concat (temporary-file-directory) "emacs-whisper.wav")
  "Location of the temporary audio file.")

(defvar whisper--ffmpeg-input-format
  (pcase system-type
    ('gnu/linux (if (or (executable-find "pulseaudio")
                        (executable-find "pipewire-pulse"))
                    "pulse"
                  "alsa"))
    ('darwin "avfoundation")
    ('windows-nt "dshow")
    (_ nil)))

(defvar whisper--ffmpeg-input-device
  (pcase whisper--ffmpeg-input-format
    ("pulse" "default")
    (_ nil)))

(defvar whisper--ffmpeg-input-file nil)

(defvar whisper--using-whispercpp nil)

(defvar whisper--progress-level "0")

(defvar whisper--mode-line-recording-indicator
  (propertize "" 'face 'font-lock-warning-face))

(defvar whisper--mode-line-transcribing-indicator
  (propertize "" 'face 'font-lock-warning-face))

(defun whisper--timestamped-transcription-buffer-name ()
  "Return a new transcription buffer name based on timestamp."
  (format "*whisper-%s*" (format-time-string "%+4Y%m%d%H%M%S")))

(defun whisper--simple-transcription-buffer-name ()
  "Return a fixed transcription buffer name."
  "*whisper-transcription-buffer*")

(defun whisper--check-buffer-read-only-p ()
  "Error out if current buffer is read-only."
  (when (and whisper-insert-text-at-point
             buffer-read-only
             (not (eq major-mode 'vterm-mode)))
    (error "Buffer is read-only, can't insert text here")))

;; Maybe sox would be a lighter choice for something this simple?
(defun whisper--record-command (output-file)
  "Produces FFmpeg command to be run given location of OUTPUT-FILE."
  (unless (executable-find "ffmpeg")
    (error "Needs FFmpeg to record audio"))

  (unless (or whisper--ffmpeg-input-file
              whisper--ffmpeg-input-format)
    (error "Set a suitable value for whisper--ffmpeg-input-format"))

  (unless (or whisper--ffmpeg-input-file
              whisper--ffmpeg-input-device)
    (error "Set a suitable value for whisper--ffmpeg-input-device"))

  `("ffmpeg"
    ,@(unless whisper--ffmpeg-input-file
        (list "-f" whisper--ffmpeg-input-format))
    "-i" ,(or whisper--ffmpeg-input-file whisper--ffmpeg-input-device)
    ,@(when (and (not whisper--ffmpeg-input-file) whisper-recording-timeout)
        (list "-t" (number-to-string whisper-recording-timeout)))
    "-ar" "16000"
    "-y" ,output-file))

(defun whisper-command (input-file)
  "Produces whisper.cpp command to be run on the INPUT-FILE.

If you want to use something other than whisper.cpp, you should override this
function to produce the command for the inference engine of your choice."
  `(,(whisper--find-whispercpp-main)
    ,@(when whisper-use-threads (list "--threads" (number-to-string whisper-use-threads)))
    ,@(when whisper-translate '("--translate"))
    ,@(when whisper-show-progress-in-mode-line '("--print-progress"))
    "--language" ,whisper-language
    "--model" ,(whisper--model-file whisper-quantize)
    "--no-timestamps"
    "--file" ,input-file))

(defalias 'whisper--transcribe-command 'whisper-command)
(make-obsolete 'whisper--transcribe-command 'whisper-command "0.1.6")

(defun whisper--mode-line-indicator (phase)
  "Determine what to show in mode line depending on PHASE."
  (if (eq phase 'recording)
      whisper--mode-line-recording-indicator
    (if (and (not whisper-server-mode) whisper--using-whispercpp)
        '(:eval (concat whisper--mode-line-transcribing-indicator whisper--progress-level "%%"))
      whisper--mode-line-transcribing-indicator)))

(defun whisper--setup-mode-line (command phase)
  "Set up PHASE appropriate indicator in the mode line.

Depending on the COMMAND we either show the indicator or hide it."
  (when whisper-show-progress-in-mode-line
    (let ((indicator `(t ,(whisper--mode-line-indicator phase))))
      (if (eq command :show)
          (cl-pushnew indicator global-mode-string :test #'equal)
        (setf global-mode-string (remove indicator global-mode-string))
        (setq whisper--progress-level "0")))
    (force-mode-line-update t)))

(defun whisper--get-whispercpp-progress (_process output)
  "Notify user of transcription progress by parsing whisper.cpp OUTPUT."
  (let ((marker "whisper_print_progress_callback: progress ="))
    (when (string-match (rx-to-string `(seq bol ,marker (* blank) (group (+ digit)) "%")) output)
      (setq whisper--progress-level (match-string 1 output))
      (force-mode-line-update))))

(defun whisper--using-whispercpp-p ()
  "Crude way to check we are in fact using whisper.cpp."
  (let ((command (car (whisper-command whisper--temp-file)))
        (pattern '(seq (or bol (any "/\\"))
                       (or "main" "whisper-cli")
                       (? ".exe")
                       eol)))
    (or (string-match-p (rx-to-string pattern) command)
        ;; for the staunch Nix user
        (string-equal command "whisper-cpp"))))

(defun whisper--find-whispercpp-main ()
  "Find whisper.cpp main binary in a backward compatible way."
  (let* ((base (expand-file-name (file-name-as-directory whisper--install-path)))
         (old-bin-name (if (eq system-type 'windows-nt) "main.exe" "main"))
         (bin-name (if (eq system-type 'windows-nt) "whisper-cli.exe" "whisper-cli"))
         (old-bin-path (concat base old-bin-name))
         (bin-path (concat base "build/bin/" bin-name)))
    (if (file-exists-p old-bin-path) old-bin-path bin-path)))

(defun whisper--find-whispercpp-server ()
  "Find whisper.cpp server binary."
  (let* ((base (expand-file-name (file-name-as-directory whisper--install-path)))
         (bin-name (if (eq system-type 'windows-nt) "whisper-server.exe" "whisper-server"))
         (bin-path (concat base "build/bin/" bin-name)))
    bin-path))

(defun whisper--server-base-url ()
  "Return the effective server base URL.
Uses `whisper-server-baseurl' if set, otherwise constructs from
`whisper-server-host' and `whisper-server-port'."
  (or whisper-server-baseurl
      (format "http://%s:%d" whisper-server-host whisper-server-port)))

(defun whisper--server-host ()
  "Extract host from server base URL for local server binding."
  (if whisper-server-baseurl
      (let ((url (url-generic-parse-url whisper-server-baseurl)))
        (or (url-host url) "127.0.0.1"))
    whisper-server-host))

(defun whisper--server-port ()
  "Extract port from server base URL for local server binding."
  (if whisper-server-baseurl
      (let* ((url (url-generic-parse-url whisper-server-baseurl))
             (port (url-port url)))
        (or port 8642))
    whisper-server-port))

(defun whisper--record-audio ()
  "Start audio recording process in the background."
  (when whisper-insert-text-at-point
    (with-current-buffer whisper--point-buffer
      (setq whisper--marker (point-marker))))
  (if whisper--ffmpeg-input-file
      (message "[*] Pre-processing media file")
    (message "[*] Recording audio")
    (whisper--setup-mode-line :show 'recording))
  (if (string-equal whisper--ffmpeg-input-file whisper--temp-file)
      (whisper--transcribe-audio)
    (setq whisper--recording-process
          (make-process
           :name "whisper-recording"
           :command (whisper--record-command whisper--temp-file)
           :connection-type nil
           :buffer nil
           :sentinel (lambda (_process event)
                       (whisper--setup-mode-line :hide 'recording)
                       (cond ((or (string-equal "finished\n" event)
                                  ;; this is would be sane
                                  (string-equal "terminated\n" event)
                                  ;; but this is reality
                                  (string-equal "exited abnormally with code 255\n" event))
                              (whisper--transcribe-audio))
                             ((string-match-p "exited abnormally with code [0-9]+\n" event)
                              (if whisper--ffmpeg-input-file
                                  (error "FFmpeg failed to convert given file")
                                (error "FFmpeg failed to record audio")))))))))

(defun whisper--ensure-server ()
  "Ensure the whisper server is running."
  (unless (and whisper--server-process
               (process-live-p whisper--server-process))
    (let ((server-buffer (get-buffer-create "*whisper-server*"))
          (error-buffer (get-buffer-create "*whisper-server-error*")))
      (setq whisper--server-process
            (make-process
             :name "whisper-server"
             :command `(,(whisper--find-whispercpp-server)
                        "--host" ,(whisper--server-host)
                        "--port" ,(number-to-string (whisper--server-port))
                        "--model" ,(whisper--model-file whisper-quantize)
                        "--language" ,whisper-language
                        "--no-timestamps"
                        ,@(when whisper-translate '("--translate"))
                        ,@(when whisper-use-threads (list "--threads" (number-to-string whisper-use-threads))))
             :buffer server-buffer
             :stderr error-buffer))
      ;; Give server time to start and verify it's running
      (sleep-for 1)
      (unless (process-live-p whisper--server-process)
        (with-current-buffer error-buffer
          (error "Failed to start whisper server: %s"
                 (buffer-substring-no-properties (point-min) (point-max))))))))

(defun whisper--pre-process-json-output ()
  "Parse JSON output in current buffer and replace it in-place with text."
  (goto-char (point-min))
  (let* ((response (json-parse-buffer))
         (text (gethash "text" response)))
    (erase-buffer)
    (insert text)))

(defun whisper--pre-process-text-output ()
  "Trim whitespace from output in current buffer."
  (goto-char (point-min))
  (skip-chars-forward " \n")
  (when (> (point) (point-min))
    (delete-region (point-min) (point)))
  (goto-char (point-max))
  (skip-chars-backward " \n")
  (when (> (point-max) (point))
    (delete-region (point) (point-max))))

(defun whisper--insert-text (text)
  "Inserts transcribed text in current buffer according to context."
  (let ((mode major-mode))
    (cond
     ((eq mode 'vterm-mode) (when (fboundp 'vterm-send-string)
                              (vterm-send-string text)))
     ((eq mode 'eat-mode) (when (and (fboundp 'eat-term-send-string) eat-terminal)
                            (eat-term-send-string eat-terminal text)))
     ((eq mode 'exwm-mode) (when (fboundp 'exwm-input--fake-key)
                             (kill-new text)
                             (exwm-input--fake-key ?\C-v)
                             (setq kill-ring (cdr kill-ring)
                                   kill-ring-yank-pointer kill-ring)))
     (t (insert text)))))

(defun whisper--handle-transcription-output (pre-processor)
  "Handle transcription output after process finishes.

PRE-PROCESSOR is a function that will be called first thing on the raw output."
  (with-current-buffer (get-buffer whisper--stdout-buffer-name)
    (funcall pre-processor)
    (when (= (buffer-size) 0)
      (error "Whisper command produced no output"))
    (goto-char (point-min))
    (run-hook-wrapped 'whisper-after-transcription-hook
                      (lambda (f)
                        (with-current-buffer (get-buffer whisper--stdout-buffer-name)
                          (save-excursion
                            (funcall f)))
                        nil))
    (when (> (buffer-size) 0)
      (if whisper-insert-text-at-point
          (with-current-buffer (marker-buffer whisper--marker)
            (let ((text (with-current-buffer (get-buffer whisper--stdout-buffer-name)
                          (buffer-string)))
                  end-pos)
              (save-excursion
                (goto-char whisper--marker)
                (whisper--insert-text text)
                (setq end-pos (point)))
              (pcase whisper-return-cursor
                ((or 'start 't) (goto-char whisper--marker))
                ('end (goto-char end-pos)))
              (run-hooks 'whisper-after-insert-hook)))
        (with-current-buffer
            (get-buffer-create (funcall whisper-transcription-buffer-name-function))
          (erase-buffer)
          (insert-buffer-substring (get-buffer whisper--stdout-buffer-name))
          (when whisper-display-transcription-buffer
            (display-buffer (current-buffer))
            (visual-line-mode))
          (run-hooks 'whisper-after-insert-hook))))))

(defun whisper--cleanup-transcription ()
  "Clean up after transcription is finished or killed."
  (set-marker whisper--marker nil)
  (setq whisper--point-buffer nil)
  (when (get-buffer whisper--stdout-buffer-name) (kill-buffer whisper--stdout-buffer-name))
  (when (get-buffer whisper--stderr-buffer-name) (kill-buffer whisper--stderr-buffer-name))
  (whisper--setup-mode-line :hide 'transcribing)
  (message nil))

(defun whisper--process-curl-request (url headers params)
  "Make curl request to URL with HEADERS and PARAMS and process response."
  (make-process
   :name "whisper-curl"
   :command `("curl" "-s"
              ,url
              ,@(mapcan (lambda (h) (list "-H" h)) headers)
              ,@(mapcan (lambda (p) (list "-F" p)) params))
   :buffer (get-buffer-create whisper--stdout-buffer-name)
   :stderr (get-buffer-create whisper--stderr-buffer-name)
   :coding 'utf-8
   :sentinel (lambda (_process event)
               (unwind-protect
                   (when (and (get-buffer whisper--stdout-buffer-name)
                              (string-equal "finished\n" event))
                     (whisper--handle-transcription-output #'whisper--pre-process-json-output))
                 (whisper--cleanup-transcription)))))

(defun whisper--transcribe-via-openai ()
  "Transcribe audio using OpenAI's Whisper API."
  (unless whisper-openai-api-key
    (error "OpenAI API key not set. Please set whisper-openai-api-key"))
  (when (and whisper-translate (string= whisper-openai-model "gpt-4o-transcribe"))
    (error "\"gpt-4o-transcribe\" can't translate; please use \"whisper-1\" in `whisper-openai-model'"))
  (message "[-] Transcribing/Translating via OpenAI Whisper API")
  (whisper--setup-mode-line :show 'transcribing)
  (setq whisper--transcribing-process
        (whisper--process-curl-request
         (file-name-concat whisper-openai-api-baseurl
                           "v1/audio/"
                           (if whisper-translate
                               "translations"
                             "transcriptions"))
         (list (concat "Authorization: Bearer " whisper-openai-api-key)
               "Content-Type: multipart/form-data")
         `(,(concat "file=@" whisper--temp-file)
           ,(concat "model=" whisper-openai-model)
           ,@(unless whisper-translate (list (concat "language=" whisper-language)))))))

(defun whisper--transcribe-via-local-server (&optional skip-start)
  "Transcribe audio using a whisper.cpp server.

When SKIP-START is non-nil, do not attempt to start a local server."
  (message "[-] Transcribing via %s server" (if skip-start "remote" "local"))
  (whisper--setup-mode-line :show 'transcribing)
  (unless skip-start
    (whisper--ensure-server))
  (setq whisper--transcribing-process
        (whisper--process-curl-request
         (file-name-concat (whisper--server-base-url) "inference")
         (list "Content-Type: multipart/form-data")
         (list (concat "file=@" whisper--temp-file)
               "temperature=0.0"
               "temperature_inc=0.2"
               "response_format=json"
               (concat "language=" whisper-language)))))

(defun whisper--transcribe-via-subprocess ()
  "Transcribe audio using local subprocess."
  (message "[-] Transcribing/Translating audio")
  (setq whisper--using-whispercpp (whisper--using-whispercpp-p))
  (whisper--setup-mode-line :show 'transcribing)
  (setq whisper--transcribing-process
        (make-process
         :name "whisper-transcribing"
         :command (whisper-command whisper--temp-file)
         :connection-type nil
         :buffer (get-buffer-create whisper--stdout-buffer-name)
         :stderr (if (and whisper-show-progress-in-mode-line whisper--using-whispercpp)
                     (make-pipe-process
                      :name "whisper-stderr"
                      :filter #'whisper--get-whispercpp-progress)
                   (get-buffer-create whisper--stderr-buffer-name))
         :coding 'utf-8
         :sentinel (lambda (_process event)
                     (unwind-protect
                         (when (and (get-buffer whisper--stdout-buffer-name)
                                    (string-equal "finished\n" event))
                           (whisper--handle-transcription-output #'whisper--pre-process-text-output))
                       (whisper--cleanup-transcription))))))

(defun whisper--transcribe-audio ()
  "Start audio transcribing process in the background."
  (pcase whisper-server-mode
    ('local (whisper--transcribe-via-local-server))
    ('remote (whisper--transcribe-via-local-server t))
    ('openai (whisper--transcribe-via-openai))
    ('nil (whisper--transcribe-via-subprocess))))

(defun whisper--check-model-consistency ()
  "Check if chosen language and model are consistent."
  (when (and (not (string-equal "en" whisper-language))
             (string-suffix-p ".en" whisper-model))
    (error "Use generic model (non .en version) for non-English languages"))

  (unless (or (= 2 (length whisper-language))
              (string-equal "auto" whisper-language))
    (error (concat "Unknown language shortcode. If unsure use 'auto'. For full list, see: "
                   "https://github.com/ggerganov/whisper.cpp/blob/master/whisper.cpp")))

  (let ((model-pattern (rx (seq bol
                                (or "tiny" "base" "small" "medium"
                                    (seq "large" (opt (seq "-v" (any "1-3") (opt "-turbo")))))
                                (opt (seq "." (= 2 (any "a-z"))))
                                eol)))
        (quantization-pattern (rx (or "q4_0" "q4_1" "q4_k" "q5_0" "q5_1" "q5_k" "q6_k" "q8_0"))))
    (unless (string-match-p model-pattern whisper-model)
      (error (concat "Speech recognition model " whisper-model " not recognised. For the list, see: "
                     "https://github.com/ggerganov/whisper.cpp/tree/master/models")))
    (when whisper-quantize
      (unless (string-match-p quantization-pattern whisper-quantize)
        (error "Quantization format not recognized")))))

(defun whisper--model-file (quantized)
  "Return path of QUANTIZED model file relative to `whisper-install-directory'."
  (let ((base (concat
               (expand-file-name (file-name-as-directory whisper-install-directory))
               "whisper.cpp/"))
        (name (if quantized (concat whisper-model "-" whisper-quantize) whisper-model)))
    (concat base "models/ggml-" name ".bin")))

(defun whisper--check-install-and-run (buffer status)
  "Run whisper after ensuring installation correctness.

This is a horrible function, and in time due a rewrite. But for now I find this
amusing and a little bit instructive as to how it became a mess.

To conduct and display installation progress, `compilation-mode' is used because
it's asynchronous and most importantly capable of handling progress output
of programs like wget.  However the asynchronicity comes with some complexity
cost when more than one tasks are run (but only one after another), as there is
no built-in async/await support, so need to use callbacks instead.

That is done by adding the callback to `compilation-finish-functions'.  Arguably
it would be simpler to use one function per task and then chain these callbacks.
However personally I preferred to logically group these together and handle
synchronisation and cleaning up in one place, hence this big function.

Conventionally, these callbacks are going to be called by passing current
compilation-buffer in BUFFER and what event triggered the callback in STATUS so
that's the function signature here.  Checking if BUFFER is indeed originating
from this particular compilation buffer and not something the user have running
elsewhere is necessary.  It's possible to make the hook buffer local, but
compilation command starts before the hook could be added so I have some
theoretical concern about possible race condition in that approach.

Small Downside of re-using same function is that we need to differentiate
whether this run is a callback or first normal call, that's what the made up
status \"whisper-start\" does.

The unfortunate price of asynchronicity is that this breaks dynamic binding
because call stack is disrupted, callbacks are executed at a later time outside
of the original dynamic context.  The fault not only lies here, but ultimately
`make-process' itself is async, so it will likely take some insane hacks that
escapes me right now, to get let bindings work like synchronous code."
  (catch 'early-return
    (unless (string-equal "whisper-start" status)
      ;; shouldn't do anything when triggered by compilation buffers from elsewhere
      (unless (eq buffer whisper--compilation-buffer)
        (throw 'early-return nil))

      ;; being here means this compilation job either finished or was interrupted
      (remove-hook 'compilation-finish-functions #'whisper--check-install-and-run)
      (when (string-equal "finished\n" status)
        (kill-buffer whisper--compilation-buffer)))

    (let ((base (concat
                 (expand-file-name (file-name-as-directory whisper-install-directory))
                 "whisper.cpp/"))
          (old-bin-name (if (eq system-type 'windows-nt) "main.exe" "main"))
          (bin-name (if (eq system-type 'windows-nt) "whisper-cli.exe" "whisper-cli"))
          (compilation-buffer-name-function '(lambda (_) whisper--compilation-buffer-name)))

      (setq whisper--install-path base)

      (when (and (not (or (string-equal "interrupt\n" status)
                          (string-prefix-p "exited abnormally with code" status)))
                 (not (or (file-exists-p (concat base old-bin-name)) ;; old location
                          (file-exists-p (concat base "build/bin/" bin-name)))))

        (when (eq whisper-install-whispercpp 'manual)
          (error (format "Couldn't find whisper.cpp install at: %s" base)))

        (if (yes-or-no-p (format "Couldn't find whisper.cpp, install it at: %s ?" base))
            (let ((make-commands
                   (concat
                    "mkdir -p " whisper-install-directory " && "
                    "cd " whisper-install-directory " && "
                    "git clone https://github.com/ggerganov/whisper.cpp && "
                    "cd whisper.cpp && "
                    "CLICOLOR=0 cmake -B build && "
                    "CLICOLOR=0 cmake --build build -j --config Release")))
              (setq whisper--compilation-buffer (get-buffer-create whisper--compilation-buffer-name))
              (add-hook 'compilation-finish-functions #'whisper--check-install-and-run)
              (compile make-commands)
              (throw 'early-return nil))
          (error "Needs whisper.cpp to be installed")))

      (when (and (not (file-exists-p (whisper--model-file nil)))
                 (not (or (string-equal "interrupt\n" status)
                          (string-prefix-p "exited abnormally with code" status))))
        (if (yes-or-no-p (format "Speech recognition model \"%s\" isn't available, download now?" whisper-model))
            (let ((make-commands
                   (concat
                    "cd " base " && "
                    "models/download-ggml-model.sh " whisper-model)))
              (setq whisper--compilation-buffer (get-buffer-create whisper--compilation-buffer-name))
              (add-hook 'compilation-finish-functions #'whisper--check-install-and-run)
              (compile make-commands)
              (throw 'early-return nil))
          (error "Needs speech recognition model to run whisper")))

      (when (and whisper-quantize
                 (not (file-exists-p (whisper--model-file t)))
                 (not (or (string-equal "interrupt\n" status)
                          (string-prefix-p "exited abnormally with code" status))))
        (if (not (file-exists-p (concat base "build/bin/quantize")))
            (let ((make-commands
                   (concat
                    "cd " base " && "
                    "make quantize" " && "
                    "echo 'Quantizing the model....'" " && "
                    "./build/bin/quantize " (whisper--model-file nil) " " (whisper--model-file t) " " whisper-quantize)))
              (setq whisper--compilation-buffer (get-buffer-create whisper--compilation-buffer-name))
              (add-hook 'compilation-finish-functions #'whisper--check-install-and-run)
              (compile make-commands)
              (throw 'early-return nil))
          (let ((quantize-command
                 (concat (concat base "build/bin/quantize")
                         " " (whisper--model-file nil) " " (whisper--model-file t) " " whisper-quantize)))
            (message "Running quantize binary...")
            (shell-command quantize-command)
            (throw 'early-return nil))))

      (when (string-equal "interrupt\n" status)
        ;; double check to be sure before cleaning up
        (when (and (file-directory-p base) (string-suffix-p "/whisper.cpp/" base))
          (if (file-exists-p (concat base "build/bin/" bin-name))
              ;; model download interrupted probably, should delete partial file
              (progn
                (message "Download interrupted, cleaning up.")
                (delete-file (concat base "models/" "ggml-" whisper-model ".bin")))
            ;; otherwise whisper.cpp compilation got interrupted
            (message "Installation interrupted, cleaning up.")
            (unless (eq whisper-install-whispercpp 'manual)
              (delete-directory whisper--install-path t))))
        (throw 'early-return nil))

      (when (string-prefix-p "exited abnormally with code" status)
        (if (eq whisper-install-whispercpp 'manual)
            (message "Compilation exited abnormally, but not deleting directory because installation is manual.")
          (progn
            (delete-directory whisper--install-path t)
            (message "Couldn't compile whisper.cpp. Check that you have Git, a C++ compiler and CMake installed.")))
        (display-buffer whisper--compilation-buffer)
        (throw 'early-return nil))

      (when (string-equal "finished\n" status)
        (unless (or whisper--ffmpeg-input-file
                    (yes-or-no-p "Speech recognition model download completed, want to record audio now?"))
          (throw 'early-return nil)))

      ;; finally
      (whisper--record-audio))))

(defun whisper-recording-p ()
  "Predicate function to check if whisper is currently recording."
  (process-live-p whisper--recording-process))

(defun whisper-transcribing-p ()
  "Predicate function to check if whisper is currently transcribing."
  (process-live-p whisper--transcribing-process))

;;;###autoload
(defun whisper-run (&optional arg)
  "Transcribe/translate audio using whisper.

When ARG is given, uses a local file as input. Otherwise records the audio.

This is a dwim function that does different things depending on current state:

- When inference engine (whisper.cpp) isn't installed, installs it first.
- When speech recognition model isn't available, downloads it.
- When installation/download is already in progress, cancels those.
- When installation is valid, starts recording audio.
- When recording is in progress, stops it and starts transcribing.
- When transcribing is in progress, cancels it."
  (interactive "P")
  (if (process-live-p whisper--transcribing-process)
      (when (yes-or-no-p "A transcribing job is already in progress, kill it?")
        (kill-process whisper--transcribing-process))

    (cond
     ((process-live-p whisper--recording-process)
      (interrupt-process whisper--recording-process))
     ((and (buffer-live-p whisper--compilation-buffer)
           (process-live-p (get-buffer-process whisper--compilation-buffer)))
      (when-let* ((proc (get-buffer-process whisper--compilation-buffer)))
	    (interrupt-process proc)))
     (t
      (setq whisper--point-buffer (current-buffer))
      (run-hooks 'whisper-before-transcription-hook)
      (when (and whisper-install-whispercpp
                 (not (memq whisper-server-mode '(openai remote))))
        (whisper--check-model-consistency))
      (setq-default
       whisper--ffmpeg-input-file
       (pcase arg
         ('nil nil)
         ('(4)
          (when-let* ((file (expand-file-name (read-file-name "Media file: " nil nil t))))
            (unless (file-readable-p file)
              (error "Media file doesn't exist or isn't readable"))
            file))
         ((and (pred file-readable-p) file) file)))
      (setq whisper--using-whispercpp nil)
      (cond
       ;; For server modes, skip whisper.cpp installation check
       (whisper-server-mode
        (whisper--record-audio))
       ;; For local whisper.cpp mode
       (whisper-install-whispercpp
        (whisper--check-install-and-run nil "whisper-start"))
       ;; For user-provided inference engine
       (t
        ;; Check the command exists
        (let ((command (car (whisper-command whisper--temp-file))))
          (if (or (file-exists-p command)
                  (executable-find command))
              (whisper--record-audio)
            (error (format "Couldn't find %s in PATH, nor is it a file" command))))))))))

;;;###autoload
(defun whisper-file ()
  "Transcribe/translate local file using whisper."
  (interactive)
  (let ((current-prefix-arg '(4)))
    (call-interactively #'whisper-run)))

(defun whisper--complete-languages ()
  "Returns completion function for interactive language change."
  (let ((completions (mapcar #'car whisper--languages)))
    (lambda (string pred action)
      (if (eq action 'metadata)
          `(metadata (display-sort-function . ,#'identity))
        (complete-with-action action completions string pred)))))

;;;###autoload
(defun whisper-select-language ()
  "Prompt user to select a language and set `whisper-language'."
  (interactive)
  (when-let* ((lang (completing-read "Language: " (whisper--complete-languages)
                                     nil t nil nil "auto"))
              (code (cdr (assoc lang whisper--languages))))
    (setq whisper-language code)
    (message "whisper-language is now set to %s (%s)" lang code)))

(provide 'whisper)
;;; whisper.el ends here
