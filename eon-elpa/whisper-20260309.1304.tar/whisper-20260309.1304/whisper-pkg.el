;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whisper" "20260309.1304"
  "Speech-to-Text interface using OpenAI's whisper model."
  '((emacs "27.1"))
  :url "https://github.com/natrys/whisper.el"
  :commit "1858f49e07e5d4b9abb1329d41a2163eddc7c285"
  :revdesc "1858f49e07e5"
  :authors '(("Imran Khan" . "imran@khan.ovh"))
  :maintainers '(("Imran Khan" . "imran@khan.ovh")))
