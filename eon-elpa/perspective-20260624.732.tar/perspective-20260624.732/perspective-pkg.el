;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective" "20260624.732"
  "Switch between named \"perspectives\" of the editor."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "http://github.com/nex3/perspective-el"
  :commit "af96b2cdaa0e10953878b17d1eef4bcd382ed6f8"
  :revdesc "af96b2cdaa0e"
  :keywords '("workspace" "convenience" "frames")
  :authors '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers '(("Natalie Weizenbaum" . "nex342@gmail.com")))
