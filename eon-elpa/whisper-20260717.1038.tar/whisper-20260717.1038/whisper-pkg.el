;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whisper" "20260717.1038"
  "Speech-to-Text interface using OpenAI's whisper model."
  '((emacs "27.1"))
  :url "https://github.com/natrys/whisper.el"
  :commit "d09b23d999ee120e98adf50fa809f8b8a5c165e6"
  :revdesc "d09b23d999ee"
  :authors '(("Imran Khan" . "imran@khan.ovh"))
  :maintainers '(("Imran Khan" . "imran@khan.ovh")))
