;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-fold" "20250711.1709"
  "Code folding using treesit."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-fold"
  :commit "74eb0ea255564cb79799e2f5c7a3f14c1cbc088b"
  :revdesc "74eb0ea25556"
  :keywords '("convenience" "folding" "tree-sitter")
  :authors '(("Junyi Hou" . "junyi.yi.hou@gmail.com")
             ("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
