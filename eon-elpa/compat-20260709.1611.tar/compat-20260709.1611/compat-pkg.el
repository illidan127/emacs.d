;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compat" "20260709.1611"
  "Emacs Lisp Compatibility Library."
  '((emacs "25.1"))
  :url "https://github.com/emacs-compat/compat"
  :commit "df03e91f1fc47503ca71e11dd507ed18ca8b5ab0"
  :revdesc "df03e91f1fc4"
  :keywords '("lisp" "maint")
  :authors '(("Philip Kaludercic" . "philipk@posteo.net")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
