;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whisper" "20260324.915"
  "Speech-to-Text interface using OpenAI's whisper model."
  '((emacs "27.1"))
  :url "https://github.com/natrys/whisper.el"
  :commit "fd9bf5787a99dd31a4bdf54d2bd9821aacf84e93"
  :revdesc "fd9bf5787a99"
  :authors '(("Imran Khan" . "imran@khan.ovh"))
  :maintainers '(("Imran Khan" . "imran@khan.ovh")))
