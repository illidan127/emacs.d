;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-workspace" "20260319.1241"
  "Dedicated workspace for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.24.2"))
  :url "https://github.com/gveres/agent-shell-workspace"
  :commit "b72ccdb0b602d9a8ecd94f16aa3456155ba0b2e9"
  :revdesc "b72ccdb0b602"
  :keywords '("convenience" "tools")
  :authors '(("Gabor Veres" . "gabor.veres@gmail.com"))
  :maintainers '(("Gabor Veres" . "gabor.veres@gmail.com")))
