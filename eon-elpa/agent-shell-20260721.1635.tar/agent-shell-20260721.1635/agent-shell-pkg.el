;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260721.1635"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4977d41ece5caeea449f4cc7655aee7b8617d98a"
  :revdesc "4977d41ece5c")
