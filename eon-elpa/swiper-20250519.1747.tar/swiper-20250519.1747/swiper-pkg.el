;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swiper" "20250519.1747"
  "Isearch with an overview.  Oh, man!."
  '((emacs "24.5")
    (ivy   "0.15.1"))
  :url "https://github.com/abo-abo/swiper"
  :commit "2257a9d0519e18f5ce7a7fafda8a1a8e5023628e"
  :revdesc "2257a9d0519e"
  :keywords '("matching")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
