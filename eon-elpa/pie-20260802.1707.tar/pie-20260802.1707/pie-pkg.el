;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pie" "20260802.1707"
  "Pie AI agent，基于 shell-maker 和 Pi SDK."
  '((emacs       "29.1")
    (shell-maker "0.91.2"))
  :url "https://github.com/dingoding/pie"
  :commit "66be8f13db29c7f04abf60654848b09617b75186"
  :revdesc "66be8f13db29")
