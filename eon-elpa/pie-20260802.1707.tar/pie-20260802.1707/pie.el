;;; pie.el --- Pie AI agent，基于 shell-maker 和 Pi SDK -*- lexical-binding: t; -*-

;; Copyright (C) 2024

;; Author: dingoding
;; URL: https://github.com/dingoding/pie
;; Package-Version: 20260802.1707
;; Package-Revision: 66be8f13db29
;; Package-Requires: ((emacs "29.1") (shell-maker "0.91.2"))

;; This package is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.

;;; Commentary:
;;
;; Pie 是一个 Emacs AI agent，通过 shell-maker 提供交互界面，
;; 直接调用 Pi coding agent SDK，不依赖 ACP 协议。
;;
;; 配置:
;;
;;   (require 'pie)
;;   (setq pie-api-key "sk-ant-...")        ; 必填：API 密钥
;;   (setq pie-api-base-url "https://...")  ; 必填：API 端点
;;   (setq pie-model "anthropic/claude-sonnet-4-5")  ; 可选，有默认值
;;
;;   M-x pie-start
;;
;; 依赖:
;;   - shell-maker (Emacs 包)
;;   - Node.js ≥ 22.19.0 + tsx
;;   - @earendil-works/pi-coding-agent (npm 包)
;;
;; 详见 docs/design.md 中的架构文档。

;;; Code:

(require 'shell-maker)
(require 'pie-bridge)
(require 'pie-prompts)

;; ── 自定义选项 ─────────────────────────────────────────────────

(defgroup pie nil
  "Pie AI agent。"
  :group 'applications)

(defcustom pie-api-key nil
  "AI provider 的 API 密钥（Anthropic、OpenAI、Google 等）。

示例:
  (setq pie-api-key \"sk-ant-...\")"
  :type 'string
  :group 'pie)

(defcustom pie-model "anthropic/claude-sonnet-4-5"
  "模型标识符，格式为 provider/model-id。

示例:
  \"anthropic/claude-sonnet-4-5\"
  \"openai/gpt-5.1\"
  \"google/gemini-2.5-pro\""
  :type 'string
  :group 'pie)

(defcustom pie-confirm-tools '("read" "bash" "write")
  "执行前需要用户确认的工具名列表。
设为 nil 则全部自动放行（跳过所有权限弹框）。
设为 t 则每次工具调用都需确认。"
  :type '(choice (const :tag "全部确认" t)
                 (repeat :tag "指定工具" string)
                 (const :tag "全部放行" nil))
  :group 'pie)

(defcustom pie-thinking-level "high"
  "Agent 思考深度等级。
\"off\" 关闭思考（最省 token），\"max\" 思考最深入。

可选值: off, minimal, low, medium, high, xhigh, max"
  :type '(choice (const "off")
                 (const "minimal")
                 (const "low")
                 (const "medium")
                 (const "high")
                 (const "xhigh")
                 (const "max"))
  :group 'pie)

(defcustom pie-api-base-url nil
  "AI provider 的 API 端点地址。

示例:
  \"https://api.anthropic.com\"
  \"https://api.openai.com/v1\"
  \"https://openrouter.ai/api/v1\""
  :type 'string
  :group 'pie)

(defcustom pie-api-type "anthropic-messages"
  "API 类型，决定 Pi SDK 如何格式化请求。

已知类型（括号内为对应厂商/产品）:

  \"anthropic-messages\"      — Anthropic Claude
  \"openai-completions\"      — OpenAI Chat Completions (含 OpenRouter / DeepSeek 等兼容 API)
  \"openai-responses\"        — OpenAI Responses API
  \"openai-codex-responses\"  — OpenAI Codex Responses
  \"azure-openai-responses\"  — Microsoft Azure OpenAI
  \"google-generative-ai\"    — Google Gemini
  \"google-vertex\"           — Google Cloud Vertex AI
  \"mistral-conversations\"   — Mistral AI
  \"bedrock-converse-stream\" — Amazon Bedrock
  \"pi-messages\"             — Pi Messages

也可设为任意自定义字符串，用于私有/代理 API。"
  :type '(choice (const "anthropic-messages")
                 (const "openai-completions")
                 (const "openai-responses")
                 (const "openai-codex-responses")
                 (const "azure-openai-responses")
                 (const "google-generative-ai")
                 (const "google-vertex")
                 (const "mistral-conversations")
                 (const "bedrock-converse-stream")
                 (const "pi-messages")
                 (string :tag "自定义")))

;; ── 命令 ────────────────────────────────────────────────────────

;;;###autoload
(defun pie-setup ()
  "安装 Pie 的 npm 依赖并编译 TypeScript。"
  (interactive)
  (let ((bridge-dir (expand-file-name "bridge" pie-bridge--directory)))
    (unless (file-exists-p (expand-file-name "package.json" bridge-dir))
      (user-error "未找到 bridge/package.json，Pie 安装可能不完整"))
    (unless (executable-find "npm")
      (user-error "未找到 npm。请安装 Node.js: https://nodejs.org"))
    (message "Pie: 正在安装 npm 依赖...")
    (let ((proc (make-process
                 :name "pie-setup"
                 :buffer (get-buffer-create "*Pie Setup*")
                 :command (list "npm" "install" "--prefix" bridge-dir)
                 :sentinel
                 (lambda (p _event)
                   (if (= (process-exit-status p) 0)
                       (progn
                         (message "Pie: npm 依赖安装完成，正在编译 TypeScript...")
                         (let ((build (make-process
                                       :name "pie-setup-build"
                                       :buffer (get-buffer-create "*Pie Setup*")
                                       :command (list "npx" "tsc" "--project" bridge-dir)
                                       :sentinel
                                       (lambda (pb _ev)
                                         (if (= (process-exit-status pb) 0)
                                             (message "Pie: 安装完成，可以 M-x pie-start 了")
                                           (message "Pie: 编译失败，请查看 *Pie Setup* buffer"))))))
                           (set-process-query-on-exit-flag build nil)))
                     (message "Pie: npm 安装失败，请查看 *Pie Setup* buffer"))))))
      (set-process-query-on-exit-flag proc nil)
      (display-buffer (get-buffer "*Pie Setup*")))))

(defun pie--ensure-deps ()
  "检查 npm 依赖是否已安装并编译。
未安装时自动提示运行 pie-setup。"
  (let ((bridge-dir (expand-file-name "bridge" pie-bridge--directory)))
    (and (file-exists-p (expand-file-name "node_modules" bridge-dir))
         (file-exists-p (expand-file-name "dist/bridge.js" bridge-dir)))))

;;;###autoload
(defun pie-start ()
  "启动 Pie AI agent 会话。"
  (interactive)
  (unless pie-api-key
    (user-error "pie-api-key 未设置。请执行 (setq pie-api-key \"...\")"))
  (unless (pie--ensure-deps)
    (if (y-or-n-p "Pie 的 npm 依赖尚未安装，是否现在安装？")
        (pie-setup)
      (user-error "请先运行 M-x pie-setup 安装依赖")))
  (let* ((config (pie--make-shell-maker-config))
         (buffer (shell-maker-start config
                                    nil    ;; no-focus
                                    nil    ;; welcome-function
                                    nil    ;; new-session
                                    "*Pie*"
                                    "Pie")))
    (with-current-buffer buffer
      (setq-local pie-api-key pie-api-key)
      (setq-local pie-model pie-model)
      (setq-local pie-bridge--pending-system-prompt (pie--collect-system-prompts))
      (setq-local default-directory (pie--resolve-cwd))
      ;; Clean up bridge when buffer is killed
      (add-hook 'kill-buffer-hook
                (lambda ()
                  (pie-bridge-stop (current-buffer)))
                nil t)
      ;; Suppress shell-maker's own prompt until bridge is ready
      (pie-bridge-start buffer))
    (switch-to-buffer buffer)
    buffer))

(defun pie--resolve-cwd ()
  "解析 Pie 会话的工作目录。
优先返回当前 project root，否则用 default-directory。"
  (or (when (fboundp 'project-root)
        (condition-case nil
            (project-root (project-current))
          (error nil)))
      default-directory))

;; ── shell-maker 配置 ───────────────────────────────────────────

(defun pie--make-shell-maker-config ()
  "构造 Pie 的 shell-maker 配置。"
  (make-shell-maker-config
   :name "pie"
   :prompt "Pie> "
   :prompt-regexp "Pie> "
   :execute-command
   (lambda (command shell)
     (condition-case err
         (let ((shell-buffer (map-elt shell :buffer)))
           (if (with-current-buffer shell-buffer
                 pie-bridge--busy)
               (user-error "Pie 正忙，请稍后")
             (pie-bridge-send-prompt command shell-buffer)))
       (error (message "pie: %s" (error-message-string err)))))))

;; ── 按键绑定 ───────────────────────────────────────────────────

(defun pie--permission-goto-first ()
  "从 buffer 末尾反向搜索最新的权限按钮并跳转。"
  (let ((found (save-excursion
                 (goto-char (point-max))
                 (text-property-search-backward
                  'pie-permission-button t t))))
    (when found
      (goto-char (prop-match-beginning found)))))

(defun pie-permission-next ()
  "跳转到下一个权限按钮。
如果没有下一个按钮则回到第一个。"
  (interactive)
  ;; 如果当前在按钮上，先跳出当前按钮
  (when (get-text-property (point) 'pie-permission-button)
    (goto-char (or (next-single-property-change (point) 'pie-permission-button)
                   (point-max))))
  ;; 跳过非按钮区域，找到下一个按钮
  (while (and (not (eobp))
              (not (get-text-property (point) 'pie-permission-button)))
    (goto-char (or (next-single-property-change (point) 'pie-permission-button)
                   (point-max))))
  ;; 没找到则回到第一个
  (unless (get-text-property (point) 'pie-permission-button)
    (pie--permission-goto-first)))

(defun pie-permission-prev ()
  "跳转到前一个权限按钮。
如果没有前一个按钮则跳到最后一个。"
  (interactive)
  ;; 如果当前在按钮上，先跳出当前按钮
  (when (get-text-property (point) 'pie-permission-button)
    (goto-char (or (previous-single-property-change (point) 'pie-permission-button)
                   (point-min))))
  ;; 跳过非按钮区域，找到前一个按钮
  (while (and (not (bobp))
              (not (get-text-property (point) 'pie-permission-button)))
    (goto-char (or (previous-single-property-change (point) 'pie-permission-button)
                   (point-min))))
  ;; 没找到则跳到最后一个
  (unless (get-text-property (point) 'pie-permission-button)
    (goto-char (point-max))
    (let ((found (text-property-search-backward
                  'pie-permission-button t t)))
      (when found
        (goto-char (prop-match-beginning found))))))

(defvar-keymap pie-shell-mode-map
  :parent shell-maker-mode-map
  :doc "Keymap for `pie-shell-mode'."
  "<tab>" #'pie-permission-next
  "TAB" #'pie-permission-next
  "<backtab>" #'pie-permission-prev)

;; 定义 major mode — 必须在 shell-maker-start 之前执行
(shell-maker-define-major-mode (pie--make-shell-maker-config) pie-shell-mode-map)

(provide 'pie)
;;; pie.el ends here
