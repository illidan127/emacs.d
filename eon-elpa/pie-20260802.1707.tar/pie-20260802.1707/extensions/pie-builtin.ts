/**
 * pie-builtin — Pie 内置扩展
 *
 * 通过 Pi 扩展系统实现：
 * - 工具调用权限确认（通过 `tool_call` 事件 + ctx.ui.confirm）
 * - 系统提示词注入（通过 `before_agent_start` 事件）
 *
 * 权限策略由环境变量 PIE_CONFIRM_TOOLS 控制：
 * - "" 或未设置：全部自动放行
 * - "*"：全部需确认
 * - "read,bash,write"：仅列表中的工具需确认
 */

import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";

export default function (pi: ExtensionAPI) {
  // ── 权限确认 ─────────────────────────────────────────────────

  pi.on("tool_call", async (event, ctx) => {
    const confirmEnv = process.env.PIE_CONFIRM_TOOLS;
    if (!confirmEnv || confirmEnv === "") return; // 全部自动放行

    const confirmAll = confirmEnv === "*";
    const confirmSet = confirmAll
      ? null
      : new Set(confirmEnv.split(",").map((s) => s.trim()));

    if (!confirmAll && !confirmSet?.has(event.toolName)) return;

    // 构造确认对话框的详情信息
    const input = event.input as Record<string, unknown> | undefined;
    const detail =
      (typeof input?.command === "string" ? input.command : "") ||
      (typeof input?.filePath === "string" ? input.filePath : "") ||
      (typeof input?.path === "string" ? input.path : "") ||
      "";

    const allowed = await ctx.ui.confirm(
      `允许 ${event.toolName}?`,
      detail || "(no details)"
    );

    if (!allowed) {
      return { block: true, reason: "用户拒绝" };
    }
  });

  // ── 系统提示词 ──────────────────────────────────────────────

  // 始终注册 before_agent_start 监听器。
  // 提示词由 Emacs 在 bridge ready 后通过 set_system_prompt 命令设置，
  // 因此需在事件触发时惰性读取（而非扩展加载时）。
  pi.on("before_agent_start", async (event, _ctx) => {
    const prompt = (globalThis as Record<string, unknown>)
      .__pie_system_prompt as string;
    if (prompt) {
      return {
        systemPrompt: (event.systemPrompt || "") + "\n\n" + prompt,
      };
    }
  });
}
