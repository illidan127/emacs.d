;;; pie-bridge.el --- Pie 的 Node.js bridge 进程管理 -*- lexical-binding: t; -*-

;; bridge 是一个 Node.js 进程，运行 bridge/src/bridge.ts。
;; 通信方式为 stdin/stdout 上的 JSON-L。

;;; Code:

(require 'map)

(defvar pie-bridge--directory (file-name-directory (or load-file-name buffer-file-name))
  "pie.el 和 bridge/ 所在的目录。")

(defvar-local pie-bridge--process nil
  "当前 shell buffer 的 bridge 进程。")

(defvar-local pie-bridge--line-buffer ""
  "用于累积进程 filter 中不完整行的缓冲区。")

(defvar-local pie-bridge--ready nil
  "非 nil 表示 bridge 已发送 'ready' 事件。")

(defvar-local pie-bridge--busy nil
  "非 nil 表示 agent 正在处理一个 prompt。")

(defvar-local pie-bridge--pending-system-prompt nil
  "待发送的系统提示词（合并后字符串）。
在 bridge ready 后通过 set_system_prompt 命令发送。")

;; ── 进程管理 ────────────────────────────────────────────────────

(defun pie-bridge-start (shell-buffer)
  "为 SHELL-BUFFER 启动 Node.js bridge 进程。
优先使用编译后的 dist/bridge.js，否则回退到 tsx 运行源码。"
  (let* ((bridge-js (expand-file-name "bridge/dist/bridge.js"
                                      pie-bridge--directory))
         (bridge-ts (expand-file-name "bridge/src/bridge.ts"
                                      pie-bridge--directory))
         (bridge-cmd (if (file-exists-p bridge-js)
                         (list "node" bridge-js)
                       (list "npx" "tsx" bridge-ts)))
         (default-directory (or (buffer-local-value 'default-directory shell-buffer)
                                default-directory))
         (process-environment
          (append (list (format "PIE_API_KEY=%s" (or pie-api-key ""))
                        (format "PIE_MODEL=%s" (or pie-model ""))
                        (format "PIE_CWD=%s" default-directory)
                        (format "PIE_API_BASE_URL=%s" (or pie-api-base-url ""))
                        (format "PIE_API_TYPE=%s" (or pie-api-type "anthropic-messages"))
                        (format "PIE_EXTENSIONS_DIR=%s"
                                (expand-file-name "extensions" pie-bridge--directory))
                        (format "PIE_CONFIRM_TOOLS=%s"
                                (cond
                                 ((eq pie-confirm-tools t) "*")
                                 ((null pie-confirm-tools) "")
                                 (t (mapconcat #'identity pie-confirm-tools ","))))
                        (format "PIE_THINKING_LEVEL=%s" (or pie-thinking-level "off")))
                  process-environment nil))
         (proc (make-process
                :name "pie-bridge"
                :buffer (generate-new-buffer " *pie-bridge*")
                :command bridge-cmd
                :connection-type 'pipe
                :coding 'utf-8
                :filter (lambda (_proc output)
                          (pie-bridge--on-output shell-buffer output))
                :sentinel (lambda (_proc _event)
                            (pie-bridge--on-exit shell-buffer _proc)))))
    (set-process-query-on-exit-flag proc nil)
    (with-current-buffer shell-buffer
      (setq-local pie-bridge--process proc)
      (setq-local pie-bridge--line-buffer "")
      (setq-local pie-bridge--ready nil)
      (setq-local pie-bridge--busy nil))
    proc))

(defun pie-bridge-stop (shell-buffer)
  "停止 SHELL-BUFFER 的 bridge 进程。"
  (with-current-buffer shell-buffer
    (when (and pie-bridge--process
               (process-live-p pie-bridge--process))
      (pie-bridge--send-json pie-bridge--process '((type . "quit")))
      (run-at-time 2 nil
                   (lambda (proc)
                     (when (process-live-p proc)
                       (kill-process proc)))
                   pie-bridge--process))
    (setq-local pie-bridge--process nil
                pie-bridge--ready nil
                pie-bridge--busy nil)))

;; ── 发送命令 ────────────────────────────────────────────────────

(defun pie-bridge-send-prompt (text shell-buffer)
  "向 SHELL-BUFFER 的 bridge 发送 prompt。"
  (with-current-buffer shell-buffer
    (when pie-bridge--process
      (setq-local pie-bridge--busy t)
      (shell-maker-write-output
       :config shell-maker--config
       :output "\n")
      (pie-bridge--send-json pie-bridge--process
                             `((type . "prompt") (message . ,text))))))

(defun pie-bridge-send-abort (shell-buffer)
  "向 SHELL-BUFFER 的 bridge 发送 abort 命令。"
  (with-current-buffer shell-buffer
    (when pie-bridge--process
      (pie-bridge--send-json pie-bridge--process '((type . "abort"))))))

(defun pie--permission-prompt-write (tool-name detail id)
  "在 buffer 中内嵌 [允许] [拒绝] 按钮，不阻塞。
ID 用于按钮回调中发送 ui_confirm_response。"
  (let* ((proc pie-bridge--process)
         (btn-beg nil)
         (btn-end nil)
         (respond (lambda (allowed)
                    (pie-bridge--send-json
                     proc
                     `((type . "ui_confirm_response")
                       (id . ,id)
                       (result . ,(if allowed t :json-false))))
                    ;; 原地替换按钮区域为授权结果
                    (save-excursion
                      (let ((inhibit-read-only t))
                        (goto-char btn-beg)
                        (delete-region btn-beg btn-end)
                        (insert (if allowed
                                     (propertize "- 允许\n" 'font-lock-face 'success)
                                   (propertize "- 拒绝\n" 'font-lock-face 'error)))))))
         (btn-props (list 'pie-permission-button t
                          'mouse-face 'highlight
                          'pointer 'hand))
         (allow-map (let ((map (make-sparse-keymap)))
                      (define-key map [mouse-1]
                                  (lambda () (interactive) (funcall respond t)))
                      (define-key map (kbd "RET")
                                  (lambda () (interactive) (funcall respond t)))
                      (define-key map [remap self-insert-command] 'ignore)
                      (define-key map "y" (lambda () (interactive) (funcall respond t)))
                      (define-key map "n" (lambda () (interactive) (funcall respond nil)))
                      map))
         (reject-map (let ((map (make-sparse-keymap)))
                       (define-key map [mouse-1]
                                   (lambda () (interactive) (funcall respond nil)))
                       (define-key map (kbd "RET")
                                   (lambda () (interactive) (funcall respond nil)))
                       (define-key map [remap self-insert-command] 'ignore)
                       (define-key map "y" (lambda () (interactive) (funcall respond t)))
                       (define-key map "n" (lambda () (interactive) (funcall respond nil)))
                       map))
         (allowed-text (apply #'propertize "[允许]"
                              'font-lock-face '(:foreground "green" :weight bold)
                              'keymap allow-map
                              btn-props))
         (rejected-text (apply #'propertize "[拒绝]"
                               'font-lock-face '(:foreground "red" :weight bold)
                               'keymap reject-map
                               btn-props))
         (prefix (concat "\n🔐 "
                         (propertize tool-name 'font-lock-face 'bold)
                         " "
                         (propertize detail 'font-lock-face 'font-lock-doc-face)
                         "  "))
         (button-line (concat allowed-text " " rejected-text
                              (propertize " (y/n)" 'font-lock-face 'font-lock-comment-face)
                              "\n")))
    ;; 先写前缀
    (shell-maker-write-output :config shell-maker--config :output prefix)
    ;; 记录按钮区域起点
    (setq btn-beg (point-max))
    ;; 写按钮行
    (shell-maker-write-output :config shell-maker--config :output button-line)
    ;; 记录按钮区域终点
    (setq btn-end (point-max))
    (pie--permission-goto-first)))

;; ── JSON 工具函数 ───────────────────────────────────────────────

(defun pie-bridge--send-json (proc alist)
  "向 PROC 的 stdin 发送一个 JSON 行。"
  (process-send-string proc
    (concat (json-serialize alist :null-object nil :false-object :json-false)
            "\n")))

(defun pie-bridge--parse-json (line)
  "将 LINE 解析为 JSON 对象 alist。
解析失败时返回 nil。"
  (condition-case nil
      (json-parse-string line :object-type 'alist
                         :null-object nil :false-object :json-false)
    (error nil)))

;; ── 输出处理 ───────────────────────────────────────────────────

(defun pie-bridge--on-output (shell-buffer output)
  "处理 bridge 进程的输出，分发事件。
OUTPUT 可能包含不完整的行，我们缓冲并逐完整行处理。"
  (when (buffer-live-p shell-buffer)
    (with-current-buffer shell-buffer
      (setq pie-bridge--line-buffer
            (concat pie-bridge--line-buffer output))
      (let ((lines (split-string pie-bridge--line-buffer "\n")))
        (setq pie-bridge--line-buffer (or (car (last lines)) ""))
        (dolist (line (butlast lines))
          (unless (string-empty-p line)
            (when-let ((json (pie-bridge--parse-json line)))
              (pie-bridge--dispatch json))))))))

(defun pie-bridge--dispatch (json)
  "分发 bridge 发来的一个 JSON 事件。
在 shell buffer 上下文中运行。"
  (let ((type (map-elt json 'type)))
    (cond
     ((equal type "ready")
      (setq-local pie-bridge--ready t)
      ;; 清除 shell-maker 自带的 prompt，显示我们的
      (let ((inhibit-read-only t))
        (erase-buffer))
      (shell-maker-write-output
       :config shell-maker--config
       :output "Pie AI agent ready.\n\n")
      (shell-maker-finish-output
       :config shell-maker--config
       :success nil)
      ;; 发送系统提示词
      (when (and pie-bridge--pending-system-prompt
                 (not (string-empty-p pie-bridge--pending-system-prompt)))
        (pie-bridge--send-json
         pie-bridge--process
         `((type . "set_system_prompt")
           (prompt . ,pie-bridge--pending-system-prompt)))
        (setq-local pie-bridge--pending-system-prompt nil)))

     ((equal type "text_delta")
      (let ((delta (map-elt json 'delta)))
        (when delta
          (shell-maker-write-output
           :config shell-maker--config
           :output delta))))

     ((equal type "thinking_delta")
      (let ((delta (map-elt json 'delta)))
        (when delta
          (shell-maker-write-output
           :config shell-maker--config
           :output (propertize delta 'font-lock-face 'font-lock-comment-face)))))

     ((equal type "tool_start")
      (let ((tool-name (map-elt json 'toolName))
            (args (map-elt json 'args)))
        (shell-maker-write-output
         :config shell-maker--config
         :output (format "\n▶ %s %s\n"
                         (propertize tool-name 'font-lock-face 'bold)
                         (propertize (or (map-elt args 'command)    ;; bash
                                         (map-elt args 'filePath)   ;; write
                                         (map-elt args 'path)       ;; read
                                         "")
                                     'font-lock-face 'font-lock-doc-face)))))

     ((equal type "tool_stream")
      (let ((delta (map-elt json 'delta)))
        (when delta
          (shell-maker-write-output
           :config shell-maker--config
           :output delta))))

     ((equal type "ui_confirm")
      (pie--permission-prompt-write
       (map-elt json 'title)
       (map-elt json 'message)
       (map-elt json 'id)))

     ((equal type "tool_end")
      (let ((is-error (map-elt json 'isError)))
        (shell-maker-write-output
         :config shell-maker--config
         :output (if (eq is-error t) "\n✗ error\n" "\n✓ done\n"))))

     ((equal type "agent_end")
      (setq-local pie-bridge--busy nil)
      (shell-maker-write-output
       :config shell-maker--config
       :output "\n")
      (shell-maker-finish-output
       :config shell-maker--config
       :success nil))

     ((equal type "error")
      (setq-local pie-bridge--busy nil)
      (shell-maker-write-output
       :config shell-maker--config
       :output (concat "\n" (propertize (format "⚠ %s" (map-elt json 'message))
                                        'font-lock-face 'error)
                       "\n"))
      (shell-maker-finish-output
       :config shell-maker--config
       :success nil))

     ((equal type "ui_notify")
      (let ((msg (map-elt json 'message))
            (ntype (map-elt json 'notifyType)))
        (shell-maker-write-output
         :config shell-maker--config
         :output (concat (propertize (format "📢 %s" msg)
                                     'font-lock-face
                                     (pcase ntype
                                       ("error" 'error)
                                       ("warning" 'warning)
                                       (_ 'font-lock-comment-face)))
                         "\n"))))

     ((equal type "goodbye")
      (setq-local pie-bridge--ready nil
                  pie-bridge--busy nil)))))

;; ── Sentinel ────────────────────────────────────────────────────

(defun pie-bridge--on-exit (shell-buffer _process)
  "处理 SHELL-BUFFER 的 bridge 进程退出。"
  (when (buffer-live-p shell-buffer)
    (with-current-buffer shell-buffer
      (setq-local pie-bridge--process nil
                  pie-bridge--ready nil
                  pie-bridge--busy nil))))

(provide 'pie-bridge)
;;; pie-bridge.el ends here
