/**
 * pie-bridge — Pie Emacs agent 的 Node.js 桥接进程
 *
 * 从 stdin 读取 JSON 命令，向 stdout 写入 JSON 事件。
 * 认证通过 PIE_API_KEY + PIE_MODEL 环境变量。
 * 扩展从 PIE_EXTENSIONS_DIR 加载。
 *
 * 命令 (stdin):
 *   {"type":"prompt","message":"..."}
 *   {"type":"abort"}
 *   {"type":"quit"}
 *   {"type":"ui_confirm_response","id":1,"result":true|false}
 *   {"type":"set_system_prompt","prompt":"..."}
 *
 * 事件 (stdout):
 *   {"type":"ready"}
 *   {"type":"text_delta","delta":"..."}
 *   {"type":"thinking_delta","delta":"..."}
 *   {"type":"tool_start","toolName":"...","args":{...}}
 *   {"type":"tool_stream","toolName":"...","delta":"..."}
 *   {"type":"tool_end","toolName":"...","result":{...},"isError":false}
 *   {"type":"agent_start"}
 *   {"type":"agent_end"}
 *   {"type":"ui_confirm","id":1,"title":"允许 read?","message":"docs/design.md"}
 *   {"type":"ui_notify","message":"...","notifyType":"info"}
 *   {"type":"error","message":"..."}
 *   {"type":"goodbye"}
 */

import { createInterface } from 'node:readline'
import { join } from 'node:path'
import type { Api } from '@earendil-works/pi-ai/compat'
import {
  createAgentSession,
  ModelRuntime,
  SessionManager,
  SettingsManager,
} from '@earendil-works/pi-coding-agent'
import type { ExtensionUIContext } from '@earendil-works/pi-coding-agent'

// ── 工具函数 ────────────────────────────────────────────────────

function emit(obj: Record<string, unknown>): void {
  process.stdout.write(JSON.stringify(obj) + '\n')
}

function emitError(message: string): void {
  emit({ type: 'error', message })
}

function fatal(message: string): never {
  emitError(message)
  process.exit(1)
}

// ── 环境变量 ────────────────────────────────────────────────────

const cwd = process.env.PIE_CWD || process.cwd()
const extensionsDir = process.env.PIE_EXTENSIONS_DIR

// 系统提示词存储（由 Emacs 在 ready 后通过 set_system_prompt 命令设置）
;(globalThis as Record<string, unknown>).__pie_system_prompt = ''

// ── UI 确认中继 ────────────────────────────────────────────────

interface PendingConfirm {
  resolve: (result: boolean) => void
}

const pendingConfirms = new Map<number, PendingConfirm>()
let confirmIdCounter = 0

// ── 扩展 UI 上下文 ─────────────────────────────────────────────

// 满足 ExtensionUIContext 接口的桩实现。
// 仅 confirm() 和 notify() 有实际逻辑；
// 其余为空实现，因为 Pie 没有 TUI。

const pieUIContext: ExtensionUIContext = {
  async confirm(title: string, message: string): Promise<boolean> {
    const id = ++confirmIdCounter
    emit({ type: 'ui_confirm', id, title, message })

    return new Promise<boolean>(resolve => {
      pendingConfirms.set(id, { resolve })
    })
  },

  notify(message: string, type?: 'info' | 'warning' | 'error'): void {
    emit({ type: 'ui_notify', message, notifyType: type ?? 'info' })
  },

  // 桩实现 — Pie 无 TUI，实际不会被调用
  async select(): Promise<string | undefined> {
    return undefined
  },
  async input(): Promise<string | undefined> {
    return undefined
  },
  onTerminalInput(): () => void {
    return () => {}
  },
  setStatus(): void {},
  setWorkingMessage(): void {},
  setWorkingVisible(): void {},
  setWorkingIndicator(): void {},
  setWidget(): void {},
  setFooter(): void {},
  setHeader(): void {},
  setTitle(): void {},
  async custom<T>(): Promise<T> {
    throw new Error('custom() 不支持')
  },
  pasteToEditor(): void {},
  setEditorText(): void {},
  getEditorText(): string {
    return ''
  },
  addAutocompleteProvider(): void {},
  setEditorComponent(): void {},
  getEditorComponent() {
    return undefined
  },
  get theme() {
    return {} as any
  },
  getAllThemes() {
    return []
  },
  getTheme() {
    return undefined
  },
  setTheme() {
    return { success: true as const }
  },
  getToolsExpanded() {
    return false
  },
  setToolsExpanded(): void {},
  setHiddenThinkingLabel(): void {},
  get editor() {
    return {} as any
  },
}

// ── 主流程 ──────────────────────────────────────────────────────

async function main(): Promise<void> {
  let shuttingDown = false
  let busy = false
  let session: Awaited<ReturnType<typeof createAgentSession>>['session'] | null = null

  function shutdown(code: number): void {
    if (shuttingDown) return
    shuttingDown = true
    // 拒绝所有等待中的确认请求
    for (const [, p] of pendingConfirms) {
      p.resolve(false)
    }
    pendingConfirms.clear()
    if (session) {
      try {
        session.dispose()
      } catch {
        /* 忽略 */
      }
    }
    emit({ type: 'goodbye' })
    process.exit(code)
  }

  process.on('SIGTERM', () => shutdown(0))
  process.on('SIGINT', () => shutdown(0))

  try {
    // 0. 校验配置
    const apiKey = process.env.PIE_API_KEY
    if (!apiKey) {
      fatal('PIE_API_KEY 未设置。请在 Emacs 中执行 (setq pie-api-key "...")')
    }

    const modelSpec = process.env.PIE_MODEL
    if (!modelSpec) {
      fatal('PIE_MODEL 未设置。请在 Emacs 中执行 (setq pie-model "...")')
    }
    const parts = modelSpec.split('/')
    const provider = parts[0]!
    const modelId = parts[1]!
    if (!modelId) {
      fatal(`无效的 PIE_MODEL "${modelSpec}"。期望格式: provider/model-id`)
    }

    // 1. 注册自定义 provider（base URL + API 类型由用户配置）
    const baseUrl = process.env.PIE_API_BASE_URL
    if (!baseUrl) {
      fatal('PIE_API_BASE_URL 未设置。请在 Emacs 中执行 (setq pie-api-base-url "...")')
    }
    const apiTypeRaw = process.env.PIE_API_TYPE
    if (!apiTypeRaw) {
      fatal('PIE_API_TYPE 未设置。请在 Emacs 中执行 (setq pie-api-type "...")')
    }
    const apiType = apiTypeRaw as Api

    const modelRuntime = await ModelRuntime.create()
    modelRuntime.registerProvider(provider, {
      baseUrl,
      api: apiType,
      models: [
        {
          id: modelId,
          name: modelId,
          reasoning: false,
          input: ['text' as const],
          cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
          contextWindow: 200_000,
          maxTokens: 16_384,
        },
      ],
    })

    // 2. 设置 API key
    await modelRuntime.setRuntimeApiKey(provider, apiKey)

    // 3. 解析模型
    const model = modelRuntime.getModel(provider, modelId)
    if (!model) {
      fatal(`注册后未找到模型: ${modelSpec}`)
    }

    // 4. 创建会话（文件持久化至 .pie/sessions/）
    const sessionDir = join(cwd, '.pie', 'sessions')
    const sessionManager = SessionManager.create(cwd, sessionDir)
    const settingsManager = SettingsManager.create(cwd, '.pie')
    settingsManager.setCompactionEnabled(false)
    settingsManager.setRetryEnabled(false)

    // 注册 Pie 内置扩展路径
    if (extensionsDir) {
      settingsManager.setExtensionPaths([extensionsDir, ...settingsManager.getExtensionPaths()])
    }

    const result = await createAgentSession({
      cwd,
      modelRuntime,
      model,
      thinkingLevel: (process.env.PIE_THINKING_LEVEL || 'high') as 'off' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh' | 'max',
      tools: ['read', 'write', 'bash'],
      sessionManager,
      settingsManager,
    })
    session = result.session

    // 5. 绑定扩展 UI 上下文：将 ctx.ui.confirm() 桥接到 Emacs
    await session.bindExtensions({ uiContext: pieUIContext })

    // 6. 订阅 SDK 事件 → 以 JSON-L 发送至 stdout
    session.subscribe(event => {
      switch (event.type) {
        case 'agent_start':
          emit({ type: 'agent_start' })
          break

        case 'agent_end':
          emit({ type: 'agent_end' })
          break

        case 'message_update': {
          const deltaEvent = event.assistantMessageEvent
          switch (deltaEvent.type) {
            case 'text_delta':
              emit({ type: 'text_delta', delta: deltaEvent.delta })
              break
            case 'thinking_delta':
              emit({ type: 'thinking_delta', delta: deltaEvent.delta })
              break
          }
          break
        }

        case 'tool_execution_start':
          emit({
            type: 'tool_start',
            toolName: event.toolName,
            args: event.args,
          })
          break

        case 'tool_execution_update':
          if (event.partialResult?.content?.[0]?.text) {
            emit({
              type: 'tool_stream',
              toolName: event.toolName,
              delta: event.partialResult.content[0].text,
            })
          }
          break

        case 'tool_execution_end':
          emit({
            type: 'tool_end',
            toolName: event.toolName,
            result: event.result,
            isError: event.isError,
          })
          break
      }
    })

    // 7. 事件驱动 stdin（必须在 ready 之前设置，确保 set_system_prompt 不会丢失）
    const rl = createInterface({ input: process.stdin })

    rl.on('line', async line => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let cmd: any
      try {
        cmd = JSON.parse(line)
      } catch {
        emitError(`命令解析失败: ${line}`)
        return
      }

      switch (cmd.type) {
        case 'prompt':
          if (busy) {
            emitError('Agent 正忙，忽略 prompt')
            return
          }
          if (!cmd.message) {
            emitError("prompt 命令缺少 'message' 字段")
            return
          }
          busy = true
          try {
            await session!.prompt(cmd.message)
          } catch (err) {
            emitError(`prompt 错误: ${err instanceof Error ? err.message : String(err)}`)
          }
          busy = false
          break

        case 'ui_confirm_response': {
          const id = cmd.id as number
          const result = cmd.result as boolean
          const pending = pendingConfirms.get(id)
          if (pending) {
            pendingConfirms.delete(id)
            pending.resolve(result === true)
          }
          break
        }

        case 'abort':
          try {
            await session!.abort()
          } catch (err) {
            emitError(`abort 错误: ${err instanceof Error ? err.message : String(err)}`)
          }
          break

        case 'quit':
          shutdown(0)
          break

        case 'set_system_prompt':
          ;(globalThis as Record<string, unknown>).__pie_system_prompt =
            (cmd.prompt as string) ?? ''
          break

        default:
          emitError(`未知命令: ${cmd.type}`)
      }
    })

    // 8. 发送 ready 信号
    emit({ type: 'ready' })
  } catch (err) {
    emitError(`致命错误: ${err instanceof Error ? err.message : String(err)}`)
    process.exit(1)
  }
}

main()
