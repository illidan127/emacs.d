import tseslint from "typescript-eslint";

export default tseslint.config(
  { ignores: ["dist/", "node_modules/"] },
  {
    files: ["src/**/*.ts"],
    extends: [...tseslint.configs.strictTypeChecked, ...tseslint.configs.stylisticTypeChecked],
    languageOptions: {
      parserOptions: {
        projectService: true,
        tsconfigRootDir: import.meta.dirname,
      },
    },
    rules: {
      // Disabled to match Project Pie's code style
      semi: "off",
      "@typescript-eslint/semi": ["error", "never"],

      quotes: "off",
      "@typescript-eslint/quotes": ["error", "single", { avoidEscape: true }],

      "comma-dangle": "off",
      "@typescript-eslint/comma-dangle": ["error", "always-multiline"],

      "object-curly-spacing": "off",
      "@typescript-eslint/object-curly-spacing": ["error", "always"],

      "arrow-parens": ["error", "as-needed"],

      "max-len": ["warn", { code: 100, ignoreComments: true, ignoreStrings: true }],

      // Allow `as any` with justification comment
      "@typescript-eslint/no-explicit-any": "warn",

      // Allow unused vars prefixed with _
      "@typescript-eslint/no-unused-vars": [
        "error",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],
    },
  },
);
