;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eon-workspace" "20260706.1017"
  "Frame-based workspaces with project root."
  '((emacs "27.1"))
  :url "https://github.com/illidan127/eon-workspace"
  :commit "f5f92e01bb720b2ccf4ffb704fe624e32c462f87"
  :revdesc "f5f92e01bb72"
  :keywords '("convenience" "workspace" "frames" "project"))
