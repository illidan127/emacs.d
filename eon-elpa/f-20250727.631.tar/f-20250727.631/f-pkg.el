;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f" "20250727.631"
  "Modern API for working with files and directories."
  '((emacs "24.1")
    (s     "1.7.0")
    (dash  "2.2.0"))
  :url "http://github.com/rejeep/f.el"
  :commit "9983806edb2f548916775835499900b520dc652e"
  :revdesc "9983806edb2f"
  :keywords '("files" "directories")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Lucien Cartier-Tilet" . "lucien@phundrak.com")))
