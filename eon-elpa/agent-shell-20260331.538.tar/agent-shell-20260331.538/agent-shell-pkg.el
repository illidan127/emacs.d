;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260331.538"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7e09aa79909760b584e534d1b0c39ed4b95ae424"
  :revdesc "7e09aa799097")
