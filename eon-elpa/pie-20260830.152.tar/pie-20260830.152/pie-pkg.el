;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pie" "20260830.152"
  "Pie AI agent."
  '((emacs "29.1"))
  :url "https://github.com/dingoding/pie"
  :commit "dac3c8583e95466436261de65b62886b60cafc03"
  :revdesc "dac3c8583e95")
