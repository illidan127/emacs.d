;;; pie.el --- Pie AI agent -*- lexical-binding: t; -*-

;; Copyright (C) 2024

;; Author: dingoding
;; URL: https://github.com/dingoding/pie
;; Package-Version: 20260830.152
;; Package-Revision: dac3c8583e95
;; Package-Requires: ((emacs "29.1"))

;; This package is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.

;;; Commentary:
;;
;; Pie 是一个 Emacs AI agent，直接调用 Pi coding agent SDK。
;; 不再依赖 shell-maker——使用自建的 pie-mode 作为 UI 层。
;;
;; 配置:
;;
;;   (require 'pie)
;;   (setq pie-api-key "sk-ant-...")        ; 必填：API 密钥
;;   (setq pie-model "anthropic/claude-sonnet-4-5")  ; 可选，有默认值（预置 provider）
;;
;;   M-x pie-start
;;
;; 依赖:
;;   - Node.js ≥ 22.19.0 + tsx
;;   - @earendil-works/pi-coding-agent (npm 包)
;;
;; 详见 docs/design.md 中的架构文档。

;;; Code:

(require 'pie-bridge)
(require 'pie-prompts)
(require 'pie-render)

;; ── 自定义选项 ─────────────────────────────────────────────────

(defgroup pie nil
  "Pie AI agent。"
  :group 'applications)

(defcustom pie-api-key nil
  "AI provider 的 API 密钥（Anthropic、OpenAI、Google 等）。

示例:
  (setq pie-api-key \"sk-ant-...\")"
  :type 'string
  :group 'pie)

(defcustom pie-model "anthropic/claude-sonnet-4-5"
  "模型标识符，格式为 provider/model-id。

示例:
  \"anthropic/claude-sonnet-4-5\"
  \"openai/gpt-5.1\"
  \"google/gemini-2.5-pro\""
  :type 'string
  :group 'pie)

(defcustom pie-confirm-tools '("read" "bash" "write")
  "执行前需要用户确认的工具名列表。
设为 nil 则全部自动放行（跳过所有权限弹框）。
设为 t 则每次工具调用都需确认。"
  :type '(choice (const :tag "全部确认" t)
                 (repeat :tag "指定工具" string)
                 (const :tag "全部放行" nil))
  :group 'pie)

(defcustom pie-thinking-level "high"
  "Agent 思考深度等级。
\"off\" 关闭思考（最省 token），\"max\" 思考最深入。

可选值: off, minimal, low, medium, high, xhigh, max"
  :type '(choice (const "off")
                 (const "minimal")
                 (const "low")
                 (const "medium")
                 (const "high")
                 (const "xhigh")
                 (const "max"))
  :group 'pie)

(defcustom pie-api-base-url nil
  "AI provider 的 API 端点地址（可选）。

模型默认取自 pi-ai 预置的 provider catalog，端点由预置配置决定，
一般无需设置本变量。仅当需要通过自定义 provider 覆盖端点时使用。"
  :type 'string
  :group 'pie)

(defcustom pie-api-type "anthropic-messages"
  "API 类型，决定 Pi SDK 如何格式化请求（可选）。

模型默认取自 pi-ai 预置的 provider catalog，API 类型由预置配置决定，
一般无需设置本变量。

已知类型（括号内为对应厂商/产品）:

  \"anthropic-messages\"      — Anthropic Claude
  \"openai-completions\"      — OpenAI Chat Completions (含 OpenRouter / DeepSeek 等兼容 API)
  \"openai-responses\"        — OpenAI Responses API
  \"openai-codex-responses\"  — OpenAI Codex Responses
  \"azure-openai-responses\"  — Microsoft Azure OpenAI
  \"google-generative-ai\"    — Google Gemini
  \"google-vertex\"           — Google Cloud Vertex AI
  \"mistral-conversations\"   — Mistral AI
  \"bedrock-converse-stream\" — Amazon Bedrock
  \"pi-messages\"             — Pi Messages

也可设为任意自定义字符串，用于私有/代理 API。"
  :type '(choice (const "anthropic-messages")
                 (const "openai-completions")
                 (const "openai-responses")
                 (const "openai-codex-responses")
                 (const "azure-openai-responses")
                 (const "google-generative-ai")
                 (const "google-vertex")
                 (const "mistral-conversations")
                 (const "bedrock-converse-stream")
                 (const "pi-messages")
                 (string :tag "自定义")))

;; ── 命令 ────────────────────────────────────────────────────────

;;;###autoload
(defun pie-setup ()
  "安装 Pie 的 npm 依赖并编译 TypeScript。"
  (interactive)
  (let ((bridge-dir (expand-file-name "bridge" pie-bridge--directory)))
    (unless (file-exists-p (expand-file-name "package.json" bridge-dir))
      (user-error "未找到 bridge/package.json，Pie 安装可能不完整"))
    (unless (executable-find "npm")
      (user-error "未找到 npm。请安装 Node.js: https://nodejs.org"))
    (message "Pie: 正在安装 npm 依赖...")
    (let ((proc (make-process
                 :name "pie-setup"
                 :buffer (get-buffer-create "*Pie Setup*")
                 :command (list "npm" "install" "--prefix" bridge-dir)
                 :sentinel
                 (lambda (p _event)
                   (if (= (process-exit-status p) 0)
                       (progn
                         (message "Pie: npm 依赖安装完成，正在编译 TypeScript...")
                         (let ((build (make-process
                                       :name "pie-setup-build"
                                       :buffer (get-buffer-create "*Pie Setup*")
                                       :command (list "npx" "tsc" "--project" bridge-dir)
                                       :sentinel
                                       (lambda (pb _ev)
                                         (if (= (process-exit-status pb) 0)
                                             (message "Pie: 安装完成，可以 M-x pie-start 了")
                                           (message "Pie: 编译失败，请查看 *Pie Setup* buffer"))))))
                           (set-process-query-on-exit-flag build nil)))
                     (message "Pie: npm 安装失败，请查看 *Pie Setup* buffer"))))))
      (set-process-query-on-exit-flag proc nil)
      (display-buffer (get-buffer "*Pie Setup*")))))

(defun pie--ensure-deps ()
  "检查 npm 依赖是否已安装并编译。
未安装时自动提示运行 pie-setup。"
  (let ((bridge-dir (expand-file-name "bridge" pie-bridge--directory)))
    (and (file-exists-p (expand-file-name "node_modules" bridge-dir))
         (file-exists-p (expand-file-name "dist/bridge.js" bridge-dir)))))

;;;###autoload
(defun pie-start ()
  "启动 Pie AI agent 会话。

若当前仓库已有活跃的 Pie 实例则切换到该实例，
否则创建新实例，buffer 命名为 \"*Pie: <仓库名>*\"。"
  (interactive)
  (unless pie-api-key
    (user-error "pie-api-key 未设置。请执行 (setq pie-api-key \"...\")"))
  (unless (pie--ensure-deps)
    (if (y-or-n-p "Pie 的 npm 依赖尚未安装，是否现在安装？")
        (pie-setup)
      (user-error "请先运行 M-x pie-setup 安装依赖")))
  (let* ((cwd (pie--resolve-cwd))
         (buffer (or (pie--find-instance cwd)
                     (pie--create-instance cwd))))
    (switch-to-buffer buffer)
    buffer))

(defun pie--find-instance (cwd)
  "返回 CWD 仓库下 bridge 进程仍活跃的 Pie 实例 buffer，无则返回 nil。
按 buffer 的 default-directory 与 CWD 是否同一目录判断归属。"
  (let ((found nil))
    (dolist (buf (buffer-list))
      (when (and (string-prefix-p "*Pie" (buffer-name buf))
                 (let ((proc (buffer-local-value 'pie-bridge--process buf)))
                   (and proc (process-live-p proc)))
                 (file-equal-p (buffer-local-value 'default-directory buf) cwd))
        (setq found buf)))
    found))

(defun pie--create-instance (cwd)
  "为 CWD 仓库创建新的 Pie 实例 buffer 并启动其 bridge 进程。
buffer 命名为 \"*Pie: <仓库名>*\"，已存在同名 buffer 时自动编号。"
  (let* ((repo-name (file-name-nondirectory (directory-file-name cwd)))
         (repo-name (if (string-empty-p repo-name) "root" repo-name))
         (buffer-name (generate-new-buffer-name (format "*Pie: %s*" repo-name)))
         (buffer (get-buffer-create buffer-name)))
    (with-current-buffer buffer
      (pie-mode)
      (setq-local default-directory cwd)
      (setq-local pie-bridge--pending-system-prompt (pie--collect-system-prompts))
      ;; Clean up bridge when buffer is killed
      (add-hook 'kill-buffer-hook
                (lambda ()
                  (pie-bridge-stop (current-buffer)))
                nil t)
      (pie-bridge-start buffer))
    (pop-to-buffer buffer)
    buffer))

(defun pie--resolve-cwd ()
  "解析 Pie 会话的工作目录。
优先返回当前 project root，否则用 default-directory。"
  (or (when (fboundp 'project-root)
        (condition-case nil
            (project-root (project-current))
          (error nil)))
      default-directory))

;; ── pie-mode ────────────────────────────────────────────────────

(defvar pie-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "RET") #'pie--send-input)
    (define-key map (kbd "C-c C-c") #'pie-send-abort)
    ;; 渲染层导航（pie-render-mode-map 的绑定也在此全局可用）
    (define-key map (kbd "C-c n") #'pie-render-next-block)
    (define-key map (kbd "C-c p") #'pie-render-prev-block)
    (define-key map (kbd "C-c f") #'pie-render-fold-all)
    (define-key map (kbd "C-c u") #'pie-render-unfold-all)
    ;; 权限按钮导航
    (define-key map (kbd "TAB") #'pie-permission-next)
    (define-key map (kbd "<backtab>") #'pie-permission-prev)
    map)
  "Keymap for `pie-mode'.")

(define-derived-mode pie-mode fundamental-mode "Pie"
  "Major mode for Pie AI agent interaction.

输出区：AI 响应以结构化块（标题行 + 内容，可折叠）形式渲染。
输入区：buffer 末尾的 Pie> 提示符行 —— 在此键入，RET 提交。

\\{pie-mode-map}"
  :group 'pie
  (setq buffer-read-only nil)
  (setq buffer-undo-list t)          ; 禁止 undo，避免用户误撤销输出
  (setq-local scroll-margin 0)
  (pie-render-mode 1))

;; ── 输入处理 ────────────────────────────────────────────────────

(defun pie--on-prompt-p ()
  "点在最末尾的 Pie> 提示符行则返回 t。
提示符的 \"Pie> \" 前缀带 read-only 属性（pie--show-prompt 插入），
AI 输出中的同形文本没有该属性——据此区分，避免误判/误删。"
  (save-excursion
    (goto-char (line-beginning-position))
    (and (looking-at "Pie> ")
         (get-text-property (point) 'read-only))))

(defun pie--show-prompt ()
  "确保 buffer 末尾有且仅有一个 Pie> 提示符行，定位光标到输入位置。

幂等：若提示符已存在则直接定位；检测并删除多余的重复提示符。"
  (let ((inhibit-read-only t))
    (save-excursion
      (goto-char (point-max))
      (while (and (pie--on-prompt-p)
                  (save-excursion
                    (forward-line -1)
                    (pie--on-prompt-p)))
        (delete-region (line-beginning-position)
                       (min (1+ (line-end-position)) (point-max)))
        (goto-char (point-max)))
      (unless (pie--on-prompt-p)
        ;; 提示符写入包在 mutation 中：这是 UI 内部写入，并非用户编辑历史区。
        ;; output-end marker 为前进型（insertion-type t），在 marker 位置插入时
        ;; marker 自动前移到插入文本之后；若不抑制 restore-history，
        ;; after-change 钩子会看到 beg < out-end 而误判为"历史区编辑"并撤销提示符。
        (pie-render--with-mutation
          (unless (bolp) (insert "\n"))
          (let ((prompt-start (point)))
            ;; 前缀 "Pie>"：rear-nonsticky 仅列 font-lock-face，read-only 保持向后传染，
            ;; 使 Emacs 30 的插入检查（barf_point_if_read_only 查 pos-1）阻止前缀内部编辑；
            ;; 末尾空格：rear-nonsticky t 放行 read-only 传染，用户输入区可自由编辑。
            (insert (propertize "Pie>" 'read-only t 'rear-nonsticky '(font-lock-face)
                                'font-lock-face 'font-lock-keyword-face)
                    (propertize " " 'read-only t 'rear-nonsticky t
                                'font-lock-face 'font-lock-keyword-face))
            (unless (and (boundp 'pie-render--output-end) pie-render--output-end)
              (setq-local pie-render--output-end (point-marker))
              (set-marker-insertion-type pie-render--output-end t))
            (set-marker pie-render--output-end prompt-start)))))
    (goto-char (point-max))
    (when (pie--on-prompt-p)
      (goto-char (+ (line-beginning-position) 5)))))

(defun pie--get-input ()
  "提取当前提示符行的用户输入文本（Pie> 之后的部分），去除首尾空白。"
  (save-excursion
    (goto-char (point-max))
    (when (pie--on-prompt-p)
      (string-trim (buffer-substring-no-properties
                    (line-beginning-position)
                    (line-end-position))
                   "Pie> " nil))))

(defun pie--clear-input ()
  "删除当前提示符行（包含 Pie> 前缀和用户输入）。"
  (let ((inhibit-read-only t))
    (save-excursion
      (goto-char (point-max))
      (when (pie--on-prompt-p)
        (delete-region (line-beginning-position)
                       (min (1+ (line-end-position)) (point-max)))))))

(defun pie--send-input ()
  "提取用户输入、写入 prompt 块、发送到 bridge、重置 busy 等待响应。"
  (interactive)
  (if pie-bridge--busy
      (message "Pie 正忙，请稍后")
    (let ((input (pie--get-input)))
      (if (or (null input) (string-empty-p input))
          (message "输入为空")
        (pie--clear-input)
        (pie-render--write-prompt input)
        (setq-local pie-bridge--busy t)
        (pie-bridge-send-prompt input)))))

;; ── 权限按钮导航 ────────────────────────────────────────────────

(defun pie--permission-goto-first ()
  "从 buffer 末尾反向搜索最新的权限按钮并跳转。"
  (let ((found (save-excursion
                 (goto-char (point-max))
                 (text-property-search-backward
                  'pie-permission-button t t))))
    (when found
      (goto-char (prop-match-beginning found)))))

(defun pie-permission-next ()
  "跳转到下一个权限按钮。
如果没有下一个按钮则回到第一个。"
  (interactive)
  (when (get-text-property (point) 'pie-permission-button)
    (goto-char (or (next-single-property-change (point) 'pie-permission-button)
                   (point-max))))
  (while (and (not (eobp))
              (not (get-text-property (point) 'pie-permission-button)))
    (goto-char (or (next-single-property-change (point) 'pie-permission-button)
                   (point-max))))
  (unless (get-text-property (point) 'pie-permission-button)
    (pie--permission-goto-first)))

(defun pie-permission-prev ()
  "跳转到前一个权限按钮。
如果没有前一个按钮则跳到最后一个。"
  (interactive)
  (when (get-text-property (point) 'pie-permission-button)
    (goto-char (or (previous-single-property-change (point) 'pie-permission-button)
                   (point-min))))
  (while (and (not (bobp))
              (not (get-text-property (point) 'pie-permission-button)))
    (goto-char (or (previous-single-property-change (point) 'pie-permission-button)
                   (point-min))))
  (unless (get-text-property (point) 'pie-permission-button)
    (pie--permission-goto-first)))

;; ── Abort ────────────────────────────────────────────────────────

(defun pie-send-abort ()
  "中断当前正在执行的 agent 请求。"
  (interactive)
  (if (and pie-bridge--process
           (process-live-p pie-bridge--process))
      (pie-bridge--send-json pie-bridge--process '((type . "abort")))
    (message "Pie: 无活跃 bridge 进程")))

(provide 'pie)
;;; pie.el ends here
