/**
 * pie-bridge — Pie Emacs agent 的 Node.js 桥接进程
 *
 * 从 stdin 读取 JSON 命令，向 stdout 写入 JSON 事件。
 * 认证通过 PIE_API_KEY + PIE_MODEL 环境变量。
 * 扩展从 PIE_EXTENSIONS_DIR 加载。
 *
 * 命令 (stdin):
 *   {"type":"prompt","message":"..."}
 *   {"type":"abort"}
 *   {"type":"quit"}
 *   {"type":"ui_confirm_response","id":1,"result":true|false}
 *   {"type":"set_system_prompt","prompt":"..."}
 *
 * 事件 (stdout) —— 与 SDK AgentSessionEvent 语义对齐（保留 type 名与关键字段）:
 *   {"type":"ready"}
 *   {"type":"agent_start"}
 *   {"type":"agent_end","willRetry":false}
 *   {"type":"message_start","role":"assistant"}
 *   {"type":"message_end","role":"assistant"}
 *   {"type":"text_delta","contentIndex":0,"delta":"..."}
 *   {"type":"thinking_delta","contentIndex":0,"delta":"..."}
 *   {"type":"tool_execution_start","toolCallId":"...","toolName":"bash","args":{...}}
 *   {"type":"tool_execution_update","toolCallId":"...","toolName":"bash","text":"...","details":{...}}
 *   {"type":"tool_execution_end","toolCallId":"...","toolName":"bash","result":{...},"isError":false}
 *   {"type":"ui_confirm","id":1,"title":"允许 read?","message":"docs/design.md"}
 *   {"type":"ui_notify","message":"...","notifyType":"info"}
 *   {"type":"error","message":"..."}
 *   {"type":"goodbye"}
 *
 * 说明：tool_execution_update 的 text 是 SDK partialResult 的累积快照（非增量），
 * 渲染端应「替换」而非「追加」。
 */

import { createInterface } from 'node:readline'
import { join } from 'node:path'
import {
  createAgentSession,
  ModelRuntime,
  SessionManager,
  SettingsManager,
} from '@earendil-works/pi-coding-agent'
import type { ExtensionUIContext } from '@earendil-works/pi-coding-agent'

// ── 工具函数 ────────────────────────────────────────────────────

function emit(obj: Record<string, unknown>): void {
  process.stdout.write(JSON.stringify(obj) + '\n')
}

function emitError(message: string): void {
  emit({ type: 'error', message })
}

function fatal(message: string): never {
  emitError(message)
  process.exit(1)
}

// ── 环境变量 ────────────────────────────────────────────────────

const cwd = process.env.PIE_CWD || process.cwd()
const extensionsDir = process.env.PIE_EXTENSIONS_DIR

// 系统提示词存储（由 Emacs 在 ready 后通过 set_system_prompt 命令设置）
;(globalThis as Record<string, unknown>).__pie_system_prompt = ''

// ── UI 确认中继 ────────────────────────────────────────────────

interface PendingConfirm {
  resolve: (result: boolean) => void
}

const pendingConfirms = new Map<number, PendingConfirm>()
let confirmIdCounter = 0

// ── 扩展 UI 上下文 ─────────────────────────────────────────────

// 满足 ExtensionUIContext 接口的桩实现。
// 仅 confirm() 和 notify() 有实际逻辑；
// 其余为空实现，因为 Pie 没有 TUI。

const pieUIContext: ExtensionUIContext = {
  async confirm(title: string, message: string): Promise<boolean> {
    const id = ++confirmIdCounter
    emit({ type: 'ui_confirm', id, title, message })

    return new Promise<boolean>(resolve => {
      pendingConfirms.set(id, { resolve })
    })
  },

  notify(message: string, type?: 'info' | 'warning' | 'error'): void {
    emit({ type: 'ui_notify', message, notifyType: type ?? 'info' })
  },

  // 桩实现 — Pie 无 TUI，实际不会被调用
  async select(): Promise<string | undefined> {
    return undefined
  },
  async input(): Promise<string | undefined> {
    return undefined
  },
  onTerminalInput(): () => void {
    return () => {}
  },
  setStatus(): void {},
  setWorkingMessage(): void {},
  setWorkingVisible(): void {},
  setWorkingIndicator(): void {},
  setWidget(): void {},
  setFooter(): void {},
  setHeader(): void {},
  setTitle(): void {},
  async custom<T>(): Promise<T> {
    throw new Error('custom() 不支持')
  },
  pasteToEditor(): void {},
  setEditorText(): void {},
  getEditorText(): string {
    return ''
  },
  addAutocompleteProvider(): void {},
  setEditorComponent(): void {},
  getEditorComponent() {
    return undefined
  },
  get theme() {
    return {} as any
  },
  getAllThemes() {
    return []
  },
  getTheme() {
    return undefined
  },
  setTheme() {
    return { success: true as const }
  },
  getToolsExpanded() {
    return false
  },
  setToolsExpanded(): void {},
  setHiddenThinkingLabel(): void {},
  get editor() {
    return {} as any
  },
}

// ── 主流程 ──────────────────────────────────────────────────────

async function main(): Promise<void> {
  let shuttingDown = false
  let busy = false
  let session: Awaited<ReturnType<typeof createAgentSession>>['session'] | null = null

  function shutdown(code: number): void {
    if (shuttingDown) return
    shuttingDown = true
    // 拒绝所有等待中的确认请求
    for (const [, p] of pendingConfirms) {
      p.resolve(false)
    }
    pendingConfirms.clear()
    if (session) {
      try {
        session.dispose()
      } catch {
        /* 忽略 */
      }
    }
    emit({ type: 'goodbye' })
    process.exit(code)
  }

  process.on('SIGTERM', () => shutdown(0))
  process.on('SIGINT', () => shutdown(0))

  try {
    // 0. 校验配置
    const apiKey = process.env.PIE_API_KEY
    if (!apiKey) {
      fatal('PIE_API_KEY 未设置。请在 Emacs 中执行 (setq pie-api-key "...")')
    }

    const modelSpec = process.env.PIE_MODEL
    if (!modelSpec) {
      fatal('PIE_MODEL 未设置。请在 Emacs 中执行 (setq pie-model "...")')
    }
    const parts = modelSpec.split('/')
    const provider = parts[0]!
    const modelId = parts[1]!
    if (!modelId) {
      fatal(`无效的 PIE_MODEL "${modelSpec}"。期望格式: provider/model-id`)
    }

    // 1. 创建 ModelRuntime（自动加载 pi-ai 预置 provider catalog）
    const modelRuntime = await ModelRuntime.create()

    // 2. 设置 API key（覆盖预置 provider 的默认认证方式）
    await modelRuntime.setRuntimeApiKey(provider, apiKey)

    // 3. 从预置 catalog 解析模型
    const model = modelRuntime.getModel(provider, modelId)
    if (!model) {
      const available = modelRuntime.getProviders().map(p => p.id).join(', ')
      fatal(`预置 catalog 中不存在模型 "${modelSpec}"。可用 provider: ${available}`)
    }

    // 4. 创建会话（文件持久化至 .pie/sessions/）
    const sessionDir = join(cwd, '.pie', 'sessions')
    const sessionManager = SessionManager.create(cwd, sessionDir)
    const settingsManager = SettingsManager.create(cwd, '.pie')
    settingsManager.setCompactionEnabled(false)
    settingsManager.setRetryEnabled(false)

    // 注册 Pie 内置扩展路径（去重，避免多次启动后重复累积）
    if (extensionsDir) {
      const existing = settingsManager.getExtensionPaths()
      settingsManager.setExtensionPaths([
        extensionsDir,
        ...existing.filter(p => p !== extensionsDir),
      ])
    }

    const result = await createAgentSession({
      cwd,
      modelRuntime,
      model,
      thinkingLevel: (process.env.PIE_THINKING_LEVEL || 'high') as 'off' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh' | 'max',
      tools: ['read', 'write', 'bash'],
      sessionManager,
      settingsManager,
    })
    session = result.session
    // 串行执行工具：pie 渲染层是单块流式模型（一次只跟踪一个打开块），
    // 并行工具会让多个 tool_execution_* 事件交错而错乱。
    session.agent.toolExecution = 'sequential'

    // 5. 绑定扩展 UI 上下文：将 ctx.ui.confirm() 桥接到 Emacs
    await session.bindExtensions({ uiContext: pieUIContext })

    // 6. 订阅 SDK 事件 → 以 JSON-L 发送至 stdout
    //
    // 穷尽处理 AgentSessionEvent（23 种）：
    //   - 透传：运行 / 消息 / 工具生命周期（渲染层需要，保留 SDK type 名与关键字段）
    //   - 丢弃：compaction / retry / summarization（pie 已禁用）、
    //           bash_execution_update（走 tool 路径，非 executeBash）、
    //           queue / session / tree 管理事件（暂无对应 UI）
    session.subscribe(event => {
      switch (event.type) {
        // ── 运行生命周期 ──────────────────────────────────
        case 'agent_start':
          emit({ type: 'agent_start' })
          break

        case 'agent_end':
          // messages 是本次运行产生的完整消息数组，体积大且已在流式中逐条送达，
          // 故不透传；仅透传 willRetry 供 UI 提示。
          emit({ type: 'agent_end', willRetry: event.willRetry })
          break

        // ── 消息生命周期 ──────────────────────────────────
        case 'message_start':
          emit({ type: 'message_start', role: event.message.role })
          break

        case 'message_end':
          emit({ type: 'message_end', role: event.message.role })
          break

        case 'message_update': {
          // assistantMessageEvent 是流式增量；透传内容增量。边界信号
          // （start / text_start / … / done / error）由 message_start / message_end
          // 提供，工具调用参数在 tool_execution_start 中已完整给出，故不再重复透传。
          const deltaEvent = event.assistantMessageEvent
          switch (deltaEvent.type) {
            case 'text_delta':
              emit({
                type: 'text_delta',
                contentIndex: deltaEvent.contentIndex,
                delta: deltaEvent.delta,
              })
              break
            case 'thinking_delta':
              emit({
                type: 'thinking_delta',
                contentIndex: deltaEvent.contentIndex,
                delta: deltaEvent.delta,
              })
              break
            // 其余子事件：start / text_start / text_end / thinking_start /
            // thinking_end / toolcall_start / toolcall_delta / toolcall_end /
            // done / error —— 不单独透传（见上注释）。
            default:
              break
          }
          break
        }

        // ── 工具执行生命周期 ──────────────────────────────
        case 'tool_execution_start':
          emit({
            type: 'tool_execution_start',
            toolCallId: event.toolCallId,
            toolName: event.toolName,
            args: event.args,
          })
          break

        case 'tool_execution_update':
          // partialResult 是累积快照（非增量），渲染端应替换而非追加。
          emit({
            type: 'tool_execution_update',
            toolCallId: event.toolCallId,
            toolName: event.toolName,
            text: event.partialResult?.content?.[0]?.text ?? '',
            details: event.partialResult?.details,
          })
          break

        case 'tool_execution_end':
          emit({
            type: 'tool_execution_end',
            toolCallId: event.toolCallId,
            toolName: event.toolName,
            result: event.result,
            isError: event.isError,
          })
          break

        // ── 显式丢弃：pie 未启用 / 暂无对应 UI ────────────
        case 'turn_start':
        case 'turn_end':
          break // 回合边界：以 agent_start / agent_end 为准

        case 'agent_settled':
          break // 运行空闲：以 agent_end + bridge busy 状态为准

        case 'queue_update':
          break // steering / followUp 队列：pie 未暴露

        case 'compaction_start':
        case 'compaction_end':
          break // compaction 已禁用（setCompactionEnabled(false)）

        case 'auto_retry_start':
        case 'auto_retry_end':
        case 'summarization_retry_scheduled':
        case 'summarization_retry_attempt_start':
        case 'summarization_retry_finished':
          break // retry 已禁用（setRetryEnabled(false)）

        case 'bash_execution_update':
          break // executeBash()（! 命令）路径；pie 的 bash 走 tool 路径

        case 'entry_appended':
        case 'session_info_changed':
          break // 会话树 / 命名：暂无对应 UI

        case 'thinking_level_changed':
          break // 思考等级变化：暂无对应 UI

        // ── 穷尽检查：SDK 新增事件时此处编译报错 ─────────
        default: {
          const _exhaustive: never = event
          void _exhaustive
          break
        }
      }
    })

    // 7. 事件驱动 stdin（必须在 ready 之前设置，确保 set_system_prompt 不会丢失）
    const rl = createInterface({ input: process.stdin })

    rl.on('line', async line => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let cmd: any
      try {
        cmd = JSON.parse(line)
      } catch {
        emitError(`命令解析失败: ${line}`)
        return
      }

      switch (cmd.type) {
        case 'prompt':
          if (busy) {
            emitError('Agent 正忙，忽略 prompt')
            return
          }
          if (!cmd.message) {
            emitError("prompt 命令缺少 'message' 字段")
            return
          }
          busy = true
          try {
            await session!.prompt(cmd.message)
          } catch (err) {
            emitError(`prompt 错误: ${err instanceof Error ? err.message : String(err)}`)
          }
          busy = false
          break

        case 'ui_confirm_response': {
          const id = cmd.id as number
          const result = cmd.result as boolean
          const pending = pendingConfirms.get(id)
          if (pending) {
            pendingConfirms.delete(id)
            pending.resolve(result === true)
          }
          break
        }

        case 'abort':
          try {
            await session!.abort()
          } catch (err) {
            emitError(`abort 错误: ${err instanceof Error ? err.message : String(err)}`)
          }
          break

        case 'quit':
          shutdown(0)
          break

        case 'set_system_prompt':
          ;(globalThis as Record<string, unknown>).__pie_system_prompt =
            (cmd.prompt as string) ?? ''
          break

        default:
          emitError(`未知命令: ${cmd.type}`)
      }
    })

    // 8. 发送 ready 信号
    emit({ type: 'ready' })
  } catch (err) {
    emitError(`致命错误: ${err instanceof Error ? err.message : String(err)}`)
    process.exit(1)
  }
}

main()
