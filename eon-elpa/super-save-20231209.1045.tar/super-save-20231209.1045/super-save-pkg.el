;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "super-save" "20231209.1045"
  "Auto-save buffers, based on your activity."
  '((emacs "25.1"))
  :url "https://github.com/bbatsov/super-save"
  :commit "b612da0b37859a23375366b725b1ab7e7fea02fd"
  :revdesc "b612da0b3785"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
